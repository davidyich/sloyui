# Capacities UI

Независимый лёгкий UI-kit в стиле Capacities для персональных проектов. React 19+, TypeScript, обычный CSS. 40 компонентов, две темы, 18 цветовых семейств, 783 цветовых токена на тему. Без runtime-зависимостей кроме React и React DOM.

## Посмотреть

```sh
npm install
npm run dev
```

Каталог: **http://127.0.0.1:4317/**. Разделы содержат интерактивные состояния, форму с валидацией, поиск токенов, поиск команд, диалоги и пример коллекции. `Cmd/Ctrl+K` открывает поиск. Тема сохраняется только в локальном каталоге.

## Подключить к своему проекту

Сначала соберите локальный пакет:

```sh
npm run build
mkdir -p artifacts
npm pack --ignore-scripts --pack-destination artifacts
```

В проекте-потребителе установите созданный `personal-capacities-ui-0.1.0.tgz` через `npm install /absolute/path/to/personal-capacities-ui-0.1.0.tgz`. Пакет не опубликован в npm; команда `npm install @personal/capacities-ui` из публичного registry пока не применима.

```tsx
import { Button, Field, Input, Tag } from '@personal/capacities-ui';
import '@personal/capacities-ui/styles.css';
import '@personal/capacities-ui/fonts.css'; // optional, self-hosted Inter + Overpass Mono

export function Example() {
  return (
    <div className="project-form">
      <Field label="Название" hint="Короткое и понятное имя">
        {props => <Input {...props} placeholder="Мой проект" />}
      </Field>
      <Tag color="teal">В работе</Tag>
      <Button variant="primary">Сохранить</Button>
    </div>
  );
}
```

CSS не сбрасывает `body` и не задаёт размеры вашей страницы. Задайте оформление оболочки в своём проекте:

```css
body {
  margin: 0;
  font-family: var(--cap-font-sans);
  background: var(--cap-bg-back);
  color: var(--cap-text-primary);
}
.project-form { display: grid; gap: var(--cap-space-4); }
```

Тему задавайте на `html`: `<html data-theme="light">` или `<html data-theme="dark">`. `light` соответствует **Light Dimmed**, выбранной светлой теме в исходном сервисе; `dark` — **Dark**. При отсутствии атрибута используется светлая тема. Для system mode читайте `prefers-color-scheme` в приложении; автоматическое переключение не навязывается библиотекой. Диалоги используют portal в `document.body`, поэтому тема должна быть на корне документа.

## Что входит

| Группа | Компоненты |
| --- | --- |
| Действия | Button, IconButton, Icon, Tooltip, Menu, Popover |
| Объекты | Badge, Tag, TypeLabel, IconBox, Avatar, Card, ObjectCard, CollectionRow, PropertyRow |
| Формы | Field, Input, Textarea, Select, Checkbox, Radio, Switch, Slider, SegmentedControl |
| Навигация | SidebarItem, Breadcrumbs, Tabs, Accordion |
| Состояния | Dialog, CommandPalette, Toast, Callout, EmptyState, Spinner, Skeleton, Progress |
| Контент | Table, CodeBlock, Separator, Kbd |

Полный API и обязательные подписи — в [agent-manifest.json](agent-manifest.json). Примеры композиций — в [docs/recipes.md](docs/recipes.md). Подробные границы восстановления — в [docs/provenance.md](docs/provenance.md).

## Варианты и токены

- `Button`: `primary`, `secondary`, `outline`, `ghost`, `danger`; размеры `xs/sm/md/lg` = 22/28/32/36 px при корне 16 px; `disabled`, `loading`, `leading`, `trailing`.
- Цветовые компоненты: 18 значений `Color`; семантические роли для тегов, иконок типов и блоков.
- Основные радиусы: `small` 4,8 px, `base` 8 px, `xl` 12 px, `2xl` 16 px. IconBox использует 32%.
- Inter: UI 13,5 px, основной текст 15 px; вся исходная шкала 11–128 px доступна как CSS variables. Overpass Mono — код.
- `--cap-text-muted` — доступная подпись. В Light Dimmed исходный `--cap-text-subtle` сохранён с контрастом 3,24:1 и не подходит для мелкого важного текста. `muted` использует более контрастную исходную роль.

```css
.my-panel {
  background: var(--cap-bg-base);
  border: 1px solid var(--cap-border-base);
  border-radius: var(--cap-radius-xl);
  padding: var(--cap-space-4);
}
```

`styles.css` уже включает `tokens.css` (191 цветовая роль на тему + основы). Для использования только переменных импортируйте `tokens.css`. Для всех 783 исходных цветов, включая редактор и палитры, дополнительно импортируйте `source-tokens.css`. Не нужно подключать все три файла одновременно.

Экспорты DTCG: `@personal/capacities-ui/tokens/light.json`, `dark.json`, `foundations.json`. Метаданные сохраняют исходные CSS-имена и OKLCH-значения; цветовые `$value` переведены в sRGB с ограничением gamut. Родные CSS остаются в OKLCH. Реальный импорт в Figma в этой работе не выполнялся.

## Для ИИ-агентов

Начните с [llms.txt](llms.txt), затем [AGENTS.md](AGENTS.md) и только нужных записей `agent-manifest.json`. Большую палитру и снимки исходного CSS загружать в контекст обычно не нужно. Полный работающий пример: [examples/ProjectBoard.tsx](examples/ProjectBoard.tsx).

## Проверка и сборка

```sh
npm run check       # types, behavioral tests, package, demo
npm run build       # distributable in dist/
npm run build:demo  # static catalog in site/
```

Показатели реальной сборки — [docs/bundle-size.json](docs/bundle-size.json); проверка токенов — [docs/token-validation.json](docs/token-validation.json). Библиотека ESM, поддерживает tree shaking; CSS указан в `sideEffects`, чтобы сборщик его не удалял. Шрифты — отдельный opt-in ресурс. Каталог и JSON-исследователь не входят в runtime библиотеки.

Поддерживаются современные браузеры с OKLCH, `color-mix`, native `dialog` и Popover API. `Select`, checkbox, radio, range и date/time через `Input` используют нативное поведение; их мелкие платформенные детали могут отличаться. Клавиатура и фокус проверены в Chrome; это не заявление о ручной проверке всех браузеров и скринридеров.

Исходный код набора — MIT. Шрифты — SIL OFL; лицензии поставляются рядом с файлами. Capacities UI не является официальным продуктом Capacities и не включает бизнес-логику, содержимое пользователя или программный код сервиса.
