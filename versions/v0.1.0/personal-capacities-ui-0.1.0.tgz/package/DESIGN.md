---
version: alpha
name: Capacities UI
description: Independent reconstruction for personal object-oriented interfaces.
colors:
  bg-back: "oklch(0.9676 0.0016 67.02)"
  bg-base: "oklch(0.9916 0.0016 67.00)"
  bg-front: "oklch(1.0000 0.0001 263.28)"
  bg-el: "oklch(0.9556 0.0016 67.03)"
  bg-el-subtle: "oklch(0.9916 0.0016 67.00)"
  bg-button-primary: "oklch(0.4098 0.0033 286.02)"
  text-primary: "oklch(0.3461 0.0069 285.94)"
  text-secondary: "oklch(0.4668 0.0039 16.75)"
  text-subtle: "oklch(0.6441 0.0061 30.65)"
  text-button-primary: "oklch(0.9556 0.0016 67.03)"
  border-base: "oklch(0.9163 0.0017 67.07)"
  border-front: "oklch(0.9163 0.0017 67.07)"
typography:
  sans:
    fontFamily: Inter
  code:
    fontFamily: Overpass Mono
  xxs:
    fontFamily: Inter
    fontSize: ".6875rem"
    lineHeight: ".875rem"
  xs:
    fontFamily: Inter
    fontSize: ".75rem"
    lineHeight: "1rem"
  sm:
    fontFamily: Inter
    fontSize: ".84375rem"
    lineHeight: "1.2rem"
  base:
    fontFamily: Inter
    fontSize: ".9375rem"
    lineHeight: "1.325rem"
  lg:
    fontFamily: Inter
    fontSize: "1.125rem"
    lineHeight: "1.625rem"
  xl:
    fontFamily: Inter
    fontSize: "1.25rem"
    lineHeight: "1.75rem"
  2xl:
    fontFamily: Inter
    fontSize: "1.5rem"
    lineHeight: "2rem"
  3xl:
    fontFamily: Inter
    fontSize: "1.875rem"
    lineHeight: "2.25rem"
rounded:
  small: "0.3rem"
  base: "0.5rem"
  xl: "0.75rem"
  2xl: "1rem"
spacing:
  base: "0.25rem"
components:
  button-primary:
    backgroundColor: "{colors.bg-button-primary}"
    textColor: "{colors.text-button-primary}"
    rounded: "{rounded.base}"
    typography: "{typography.sm}"
  panel:
    backgroundColor: "{colors.bg-base}"
    rounded: "{rounded.xl}"
---

## Overview

Реконструированный дизайн для интерфейсов с коллекциями объектов. Разделяйте боковую навигацию и основное содержимое поверхностями. Используйте компактные строки, цветные обозначения типов и теги.

## Colors

Различайте фоновый слой, основную панель и всплывающую поверхность с помощью ролей back, base и front. Primary-кнопка использует нейтральную инверсию текста и фона. Цветовые семейства применяйте к типам объектов, тегам и содержимому информационных блоков.

## Themes

Light соответствует Light Dimmed. Dark использует те же роли. Меняйте набор значений на корне документа, чтобы порталы и основная страница сохраняли одну тему.

| Role | Light Dimmed | Dark |
| --- | --- | --- |
| bg-back | `oklch(0.9676 0.0016 67.02)` | `oklch(0.1605 0.0063 285.63)` |
| bg-base | `oklch(0.9916 0.0016 67.00)` | `oklch(0.1971 0.0060 285.78)` |
| bg-front | `oklch(1.0000 0.0001 263.28)` | `oklch(0.2191 0.0058 285.84)` |
| bg-el | `oklch(0.9556 0.0016 67.03)` | `oklch(0.2987 0.0072 285.88)` |
| bg-el-subtle | `oklch(0.9916 0.0016 67.00)` | `oklch(0.2574 0.0056 285.92)` |
| bg-button-primary | `oklch(0.4098 0.0033 286.02)` | `oklch(0.9285 0.0017 67.06)` |
| text-primary | `oklch(0.3461 0.0069 285.94)` | `oklch(1.0000 0.0001 263.28)` |
| text-secondary | `oklch(0.4668 0.0039 16.75)` | `oklch(0.9163 0.0017 67.07)` |
| text-subtle | `oklch(0.6441 0.0061 30.65)` | `oklch(0.7161 0.0060 30.59)` |
| text-button-primary | `oklch(0.9556 0.0016 67.03)` | `oklch(0.2574 0.0056 285.92)` |
| border-base | `oklch(0.9163 0.0017 67.07)` | `oklch(0.2987 0.0072 285.88)` |
| border-front | `oklch(0.9163 0.0017 67.07)` | `oklch(0.2987 0.0072 285.88)` |

## Typography

Используйте sans для элементов интерфейса и code для фрагментов кода. Для обычных контролов применяйте шкалу sm, для основного текста — base. Заголовки отделяйте размером и весом; метаданные оформляйте меньшей шкалой.

## Layout

Стройте отступы от базового spacing. Располагайте действия строки справа, тип объекта — слева от названия. Длинные списки сохраняйте прокручиваемыми и доступными с клавиатуры.

## Elevation & Depth

Отделяйте панели тонкой границей. Добавляйте тень всплывающим меню и диалогам. Для обычных карточек используйте границу и изменение поверхности при наведении.

## Shapes

Используйте small для тегов и компактных обозначений, base для кнопок и полей, xl для карточек и панелей. Иконки типов оформляйте через IconBox.

## Components

Стройте формы через Field и нативные контролы. Для операций над объектом используйте ObjectCard или CollectionRow; для неинтерактивных групп — Card. Поддерживайте состояния загрузки, недоступности, ошибки и пустого результата. Для мелких читаемых подписей используйте доступную роль text-muted набора.
