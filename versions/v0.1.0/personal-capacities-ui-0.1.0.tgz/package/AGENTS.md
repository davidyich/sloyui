# Capacities UI — project and consumer instructions

Пишите пользователю по-русски. Код и идентификаторы — на английском.

## Read narrowly

1. Read `llms.txt` for entry points.
2. Read only the relevant records in `agent-manifest.json`.
3. Use `docs/recipes.md` or `examples/ProjectBoard.tsx` for composition.
4. Open `src/components/<group>.tsx` only when changing behavior.
5. Do not load `source/loaded-stylesheets.json` or entire token catalogs into agent context unless auditing provenance.

## Design contract

- Reuse exported components and their typed variants before creating a new component.
- Import `styles.css` once; it includes runtime tokens. Fonts and full source tokens are opt-in.
- Use `--cap-*` semantic roles. Do not scatter literal brand colors into consumer pages.
- Put `data-theme="light"` or `"dark"` on `html`; portals inherit that theme.
- Light means the observed Light Dimmed theme. Preserve source provenance when updating captures.
- Use `--cap-text-muted` for readable small supporting text. Original `--cap-text-subtle` remains available for exact source inspection.
- Use Inter, existing size tokens, and weight 400/500/600 for normal interfaces.
- Use real data/state and meaningful actions. Keep empty, loading, disabled and error states in scope.
- CSS classes are prefixed `cap-`; layout and application-specific state belong to the consumer.

## Interaction contract

- Icon-only actions require a label. Fields use `Field` render props or equivalent label/id/description wiring.
- Dialog and CommandPalette are controlled with `open` and `onOpenChange`.
- Modal content is portaled to body. Do not wrap dialogs in another focus trap.
- Tooltip takes one focusable React element forwarding `aria-describedby`.
- Tabs require unique item values, a valid active value and an accessible group label.
- Radio inputs in one choice group share a `name`; separate groups use distinct names.
- ObjectCard and CollectionRow render buttons; do not nest buttons/links inside their content.
- Toast is a presentation component with `role="status"`; consumer controls placement, lifetime and dismissal. Do not auto-dismiss actionable content before it can be used.
- Keep reduced motion and native keyboard behavior intact.

## Development

`npm run dev` starts the catalogue at `http://127.0.0.1:4317`.
`npm run check` validates types, interactions, tokens, package and demo build.
Generated `src/styles/tokens.css`, `source-tokens.css`, and `src/tokens/*` are built by `scripts/build-tokens.mjs` from audited source files. Change the generator/source, then regenerate; do not hand-edit outputs.
Keep runtime dependencies empty. React/React DOM are peer dependencies. Avoid a CSS framework, icon package, router or animation runtime for small additions.
Before delivery run `git diff --check`, and verify changed interactions in the browser. `docs/verification.md` records the checked scope, not hypothetical guarantees.

Global user rules still apply. This file governs only this UI-kit and its intentional use.
