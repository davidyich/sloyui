# Композиции для проектов

Примеры рассчитаны на React 19 и подключённый `@personal/capacities-ui/styles.css`. При обычной работе достаточно этой страницы и записей нужных компонентов в `agent-manifest.json`.

## Тема без мерцания

Задайте `data-theme` на сервере или в исходном HTML до первого рендера. При переключении обновляйте `document.documentElement.dataset.theme`. Сохранение предпочтения и обработка system mode принадлежат приложению. Для root без атрибута библиотека выбирает Light Dimmed.

```tsx
import { IconButton } from '@personal/capacities-ui';
import { useState } from 'react';

export function ThemeToggle() {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  return <IconButton
    label={theme === 'light' ? 'Тёмная тема' : 'Светлая тема'}
    icon={theme === 'light' ? 'moon' : 'sun'}
    onClick={() => {
      const next = theme === 'light' ? 'dark' : 'light';
      document.documentElement.dataset.theme = next;
      setTheme(next);
    }}
  />;
}
```

## Форма с валидацией

```tsx
import { Button, Field, Input } from '@personal/capacities-ui';
import { useState } from 'react';

export function ProjectForm({ save }: { save: (title: string) => Promise<void> }) {
  const [title, setTitle] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  return <form onSubmit={async e => {
    e.preventDefault();
    if (!title.trim()) { setError('Введите название'); return; }
    setError(''); setBusy(true);
    try { await save(title.trim()); }
    catch { setError('Не удалось сохранить. Попробуйте ещё раз.'); }
    finally { setBusy(false); }
  }}>
    <Field label="Название проекта" error={error} required>
      {props => <Input {...props} value={title} onChange={e => setTitle(e.target.value)} />}
    </Field>
    <Button type="submit" variant="primary" loading={busy}>Сохранить</Button>
  </form>;
}
```

`Field` передаёт `id`, `required`, `aria-invalid` и `aria-describedby`. Не теряйте эти props при оборачивании поля. Кнопка по умолчанию имеет `type="button"`; submit указывайте явно.

## Коллекция с фильтром и созданием

Полная компилируемая композиция — `examples/ProjectBoard.tsx`: поиск, карточки, списки, empty state, диалог и создание объекта. Состояние остаётся в React и легко заменяется собственным API.

## Кнопка с контекстными действиями

```tsx
import { Menu } from '@personal/capacities-ui';

export function ObjectActions({ open, archive }: { open: () => void; archive: () => void }) {
  return <Menu label="Действия с объектом" items={[
    { id: 'open', label: 'Открыть', icon: 'external', onSelect: open },
    { id: 'archive', label: 'Архивировать', icon: 'folder', separator: true, onSelect: archive },
  ]} />;
}
```

Menu поддерживает стрелки, Home/End, выбор Enter/Space, поиск по первой букве и Escape. `shortcut` — отображение клавиши, а не регистрация глобального сочетания.

## Глобальный поиск

Передавайте `CommandPalette` массив команд `{ id, label, description?, icon?, shortcut?, onSelect }`. Приложение само регистрирует `Cmd/Ctrl+K` и управляет `open`. Поиск локальный, без обращения к сети. Для большого серверного поиска используйте собственный слой данных и отдельный компонент.

## Подключение без React

`tokens.css` не зависит от фреймворка. Классы визуальных примитивов в `styles.css` тоже обычный CSS:

```html
<button class="cap-button" data-size="md" data-variant="primary" type="button">Создать</button>
<span class="cap-tag" data-color="purple">Исследование</span>
```

Сложные контролы требуют соответствующего поведения, ARIA и фокуса; один класс не превращает div в доступный диалог или меню.
