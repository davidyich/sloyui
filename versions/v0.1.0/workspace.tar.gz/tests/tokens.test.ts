import { describe, expect, it } from 'vitest';
import light from '../src/tokens/light.json';
import dark from '../src/tokens/dark.json';
import catalog from '../src/tokens/catalog.json';
describe('Design token contracts', () => {
  it('has matching, complete light and dark color sets', () => { expect(Object.keys(light).sort()).toEqual(Object.keys(dark).sort()); expect(Object.keys(light)).toHaveLength(783); expect(catalog).toHaveLength(783); });
  it('resolves every alias without cycles and uses valid DTCG colors', () => {
    for (const tokens of [light, dark]) {
      const map = tokens as Record<string, { $type: string; $value: string | { colorSpace: string; components: number[]; alpha: number } }>;
      const resolve = (name: string, seen: string[] = []): { colorSpace: string; components: number[]; alpha: number } => {
        expect(seen).not.toContain(name); expect(map[name]).toBeDefined(); const value = map[name].$value;
        return typeof value === 'string' ? resolve(value.slice(1, -1), [...seen, name]) : value;
      };
      for (const name of Object.keys(map)) { const color = resolve(name); expect(color.colorSpace).toBe('srgb'); expect(color.components).toHaveLength(3); for (const n of [...color.components, color.alpha]) { expect(n).toBeGreaterThanOrEqual(0); expect(n).toBeLessThanOrEqual(1); } }
    }
  });
  it('keeps all 18 accents in the compact runtime theme', () => {
    for (const hue of 'gray rose pink fuchsia purple violet indigo blue sky cyan teal emerald green lime yellow amber orange red'.split(' ')) for (const role of ['tag-bg', 'tag-text', 'type-label-text', 'type-label-bg', 'type-label-border', 'block-bg']) expect(catalog.find(t => t.name === `--cap-${role}-${hue}`)?.runtime).toBe(true);
  });
});
