import { readFile, writeFile, mkdir } from 'node:fs/promises';
const read = async p => JSON.parse(await readFile(new URL('../' + p, import.meta.url), 'utf8'));
const hues = 'gray rose pink fuchsia purple violet indigo blue sky cyan teal emerald green lime yellow amber orange red'.split(' ');
const sources = { light: await read('source/light-css.json'), dark: await read('source/dark-css.json') };
const rules = await read('source/token-rules.json');
const base = rules.find(r => r.selector === ':root, :host' && r.context === ' theme').variables;
const prefix = name => name.replace(/^--/, '--cap-');
const replaceRefs = value => value.replace(/var\((--[\w-]+)/g, (_, name) => `var(${prefix(name)}`);
const foundations = Object.fromEntries(Object.entries(base).filter(([k]) => /^--(font-|line-height-|radius-|shadow|default-transition|spacing$)/.test(k)));
for (const [k, v] of Object.entries(sources.dark.declared)) if (/^--(el-|border-radius)/.test(k)) foundations[k] = v;
const space = { 0: '0px', 1: '.25rem', 2: '.5rem', 3: '.75rem', 4: '1rem', 5: '1.25rem', 6: '1.5rem', 8: '2rem', 10: '2.5rem', 12: '3rem', 16: '4rem' };
for (const [k, v] of Object.entries(space)) foundations[`--space-${k}`] = v;
foundations['--radius-full'] = '9999px';
const declarationBlock = obj => Object.entries(obj).map(([k, v]) => `  ${prefix(k)}: ${replaceRefs(v)};`).join('\n');
const isColor = value => /^(oklch\(|#)/.test(value);
// Keep component-facing roles in the default CSS; full editor/palette roles are opt-in.
const isCore = k => /^(--bg-|--border-|--text-|--input-|--ring-|--tag-|--type-label-|--block-(bg|text)-|--code-(bg|border|text)$|--(internal|external)-link)/.test(k);
const selectors = { light: ':root, [data-theme="light"]', dark: '[data-theme="dark"]' };
let core = '/* Generated from observed Capacities values. Do not hand-edit. */\n:root, [data-theme] {\n' + declarationBlock(foundations) + '\n}\n';
let full = '/* Optional complete source roles and palettes, namespaced. */\n';
const modeTokens = {};
const resolve = (key, vars, seen = new Set()) => {
  if (seen.has(key)) throw new Error(`Token cycle: ${key}`);
  if (!(key in vars)) throw new Error(`Missing token: ${key}`);
  const next = new Set([...seen, key]);
  return vars[key].replace(/var\((--[\w-]+)\)/g, (_, k) => resolve(k, vars, next));
};
function srgb(value) {
  if (value.startsWith('#')) {
    let hex = value.slice(1); if (hex.length <= 4) hex = [...hex].map(x => x + x).join('');
    return { colorSpace: 'srgb', components: [0, 2, 4].map(i => parseInt(hex.slice(i, i + 2), 16) / 255), alpha: hex.length === 8 ? parseInt(hex.slice(6), 16) / 255 : 1 };
  }
  const [l, c, h, alpha = 1] = value.match(/[\d.]+/g).map(Number);
  const a = c * Math.cos(h * Math.PI / 180), b = c * Math.sin(h * Math.PI / 180);
  const L = (l + .3963377774 * a + .2158037573 * b) ** 3, M = (l - .1055613458 * a - .0638541728 * b) ** 3, S = (l - .0894841775 * a - 1.291485548 * b) ** 3;
  const rgb = [4.0767416621 * L - 3.3077115913 * M + .2309699292 * S, -1.2684380046 * L + 2.6097574011 * M - .3413193965 * S, -.0041960863 * L - .7034186147 * M + 1.707614701 * S];
  return { colorSpace: 'srgb', components: rgb.map(x => +Math.max(0, Math.min(1, x <= .0031308 ? x * 12.92 : 1.055 * x ** (1 / 2.4) - .055)).toFixed(8)), alpha };
}
const catalog = [];
for (const [mode, source] of Object.entries(sources)) {
  const values = Object.fromEntries(Object.keys(source.declared).map(k => [k, resolve(k, source.declared)]));
  const colors = Object.fromEntries(Object.entries(values).filter(([, v]) => isColor(v)));
  core += `${selectors[mode]} {\n  color-scheme: ${mode};\n  --cap-text-muted: var(--cap-text-${mode === 'light' ? 'secondary' : 'subtle'});\n${declarationBlock(Object.fromEntries(Object.entries(colors).filter(([k]) => isCore(k))))}\n}\n`;
  full += `${selectors[mode]} {\n${declarationBlock(source.declared)}\n}\n`;
  const tokens = {};
  // Preserve direct source aliases; do not infer aliases merely from equal colors.
  for (const [k, v] of Object.entries(colors)) {
    const alias = source.declared[k].match(/^var\((--[\w-]+)\)$/);
    tokens[k.slice(2)] = { $type: 'color', $value: alias ? `{${alias[1].slice(2)}}` : srgb(v), $extensions: { 'capacities-ui': { css: prefix(k), source: k, original: source.declared[k], theme: source.observedThemeName ?? mode } } };
    if (mode === 'light') catalog.push({ name: prefix(k), original: k, group: k.startsWith('--colors-') ? 'palette' : k.split('-')[2], light: v, dark: resolve(k, sources.dark.declared), runtime: isCore(k) });
  }
  modeTokens[mode] = tokens;
  await writeFile(new URL(`../src/tokens/${mode}.json`, import.meta.url), JSON.stringify(tokens, null, 2) + '\n');
}
const lightKeys = Object.keys(modeTokens.light).sort(), darkKeys = Object.keys(modeTokens.dark).sort();
if (JSON.stringify(lightKeys) !== JSON.stringify(darkKeys)) throw new Error('Theme token sets differ');
for (const mode of Object.values(modeTokens)) for (const [k, t] of Object.entries(mode)) {
  if (typeof t.$value === 'string' && !mode[t.$value.slice(1, -1)]) throw new Error(`Broken alias ${k}`);
}
const accents = hues.map(h => `[data-color="${h}"] { --cap-accent-bg: var(--cap-tag-bg-${h}); --cap-accent-text: var(--cap-tag-text-${h}); --cap-accent-soft: var(--cap-type-label-bg-${h}); --cap-accent-ink: var(--cap-type-label-text-${h}); --cap-accent-border: var(--cap-type-label-border-${h}); --cap-accent-block: var(--cap-block-bg-${h}); }`).join('\n');
await writeFile(new URL('../src/styles/tokens.css', import.meta.url), core + accents + '\n');
await writeFile(new URL('../src/styles/source-tokens.css', import.meta.url), full);
await writeFile(new URL('../src/tokens/catalog.json', import.meta.url), JSON.stringify(catalog));
const foundationTokens = Object.fromEntries(Object.entries(foundations).filter(([k, v]) => !v.includes('var(') && /^(--(space-|radius-|el-|border-radius-|font-size-))/.test(k)).map(([k, v]) => [k.slice(2), { $type: 'dimension', $value: { value: parseFloat(v), unit: v.endsWith('rem') ? 'rem' : 'px' }, $description: k.startsWith('--space-') || k === '--radius-full' ? 'Kit normalization; 4px-based scale.' : 'Observed CSS declaration.' }]));
for (const family of ['sans', 'serif', 'mono', 'code']) foundationTokens[`font-${family}`] = { $type: 'fontFamily', $value: foundations[`--font-${family}`].split(',').map(s => s.trim().replaceAll('"', '')) };
for (const [k, v] of Object.entries(foundations)) {
  if (k.startsWith('--font-weight-')) foundationTokens[k.slice(2)] = { $type: 'fontWeight', $value: Number(v) };
  if (k.startsWith('--font-size-')) {
    const scale = k.slice('--font-size-'.length), line = foundations[`--line-height-${scale}`];
    if (line) foundationTokens[`typography-${scale}`] = { $type: 'typography', $value: { fontFamily: '{font-sans}', fontSize: `{font-size-${scale}}`, fontWeight: '{font-weight-normal}', letterSpacing: { value: 0, unit: 'px' }, lineHeight: line.endsWith('rem') ? +(parseFloat(line) / parseFloat(v)).toFixed(5) : Number(line) } };
  }
}
await writeFile(new URL('../src/tokens/foundations.json', import.meta.url), JSON.stringify(foundationTokens, null, 2));
await mkdir(new URL('../docs/', import.meta.url), { recursive: true });
await writeFile(new URL('../docs/token-validation.json', import.meta.url), JSON.stringify({ colorTokensPerTheme: lightKeys.length, paletteTokens: lightKeys.filter(k => k.startsWith('colors-')).length, runtimeColorsPerTheme: catalog.filter(t => t.runtime).length, foundations: Object.keys(foundations).length, accents: hues.length, matchingThemes: true, sourceDarkCapturedAt: sources.dark.capturedAt, sourceLightCapturedAt: sources.light.capturedAt ?? '2026-09-07 (historical capture)' }, null, 2));
console.log(`Tokens: ${lightKeys.length} colors × 2 themes, ${catalog.filter(t => t.runtime).length} runtime roles, ${hues.length} accents.`);
