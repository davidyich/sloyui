import { forwardRef, useEffect, useId, useRef, type InputHTMLAttributes, type SelectHTMLAttributes, type TextareaHTMLAttributes, type ReactNode, type HTMLAttributes } from 'react';
import { cx, type Size } from './primitives.js';
export const Input = /* @__PURE__ */ forwardRef<HTMLInputElement, Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> & { size?: Size }>(function Input({ size = 'md', className, ...props }, ref) {
  return <input ref={ref} data-size={size} className={cx('cap-input', className)} {...props} />;
});
export const Textarea = /* @__PURE__ */ forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea({ className, ...props }, ref) { return <textarea ref={ref} className={cx('cap-input', 'cap-textarea', className)} {...props} />; });
export const Select = /* @__PURE__ */ forwardRef<HTMLSelectElement, Omit<SelectHTMLAttributes<HTMLSelectElement>, 'size'> & { size?: Size }>(function Select({ size = 'md', className, children, ...props }, ref) {
  return <select ref={ref} className={cx('cap-input', 'cap-select', className)} data-size={size} {...props}>{children}</select>;
});
export function Field({ label, hint, error, required, children, className }: { label: string; hint?: string; error?: string; required?: boolean; className?: string; children: (props: { id: string; 'aria-describedby'?: string; 'aria-invalid'?: true; required?: boolean }) => ReactNode }) {
  const id = useId(), description = error || hint;
  return <div className={cx('cap-field', className)}><label htmlFor={id}>{label}{required && <span aria-hidden="true"> *</span>}</label>{children({ id, 'aria-describedby': description ? `${id}-hint` : undefined, 'aria-invalid': error ? true : undefined, required })}{description && <span id={`${id}-hint`} className={cx('cap-field-hint', error && 'cap-error')} role={error ? 'alert' : undefined}>{description}</span>}</div>;
}
export function Checkbox({ label, indeterminate, className, ...props }: Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & { label: ReactNode; indeterminate?: boolean }) {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { if (ref.current) ref.current.indeterminate = !!indeterminate; }, [indeterminate]);
  return <label className={cx('cap-check-label', className)}><input ref={ref} type="checkbox" className="cap-checkbox" {...props} /><span>{label}</span></label>;
}
export function Radio({ label, className, ...props }: Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & { label: ReactNode }) {
  return <label className={cx('cap-check-label', className)}><input type="radio" className="cap-radio" {...props} /><span>{label}</span></label>;
}
export function Switch({ label, className, ...props }: Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & { label: ReactNode }) {
  return <label className={cx('cap-switch-label', className)}><input type="checkbox" role="switch" className="cap-switch" {...props} /><span>{label}</span></label>;
}
export function Slider({ label, className, ...props }: Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> & { label: string }) {
  const id = useId(); return <div className={cx('cap-field', className)}><label htmlFor={id}>{label}</label><input id={id} type="range" className="cap-slider" {...props} /></div>;
}
export interface Choice { value: string; label: string; disabled?: boolean; icon?: ReactNode }
export function SegmentedControl({ options, value, onValueChange, label, className, ...props }: Omit<HTMLAttributes<HTMLDivElement>, 'onChange'> & { options: Choice[]; value: string; onValueChange: (value: string) => void; label: string }) {
  const name = useId();
  return <div className={cx('cap-segmented', className)} role="radiogroup" aria-label={label} {...props}>{options.map(option => <label className="cap-segment" key={option.value}><input type="radio" name={name} value={option.value} checked={value === option.value} disabled={option.disabled} onChange={() => onValueChange(option.value)} /><span>{option.icon}{option.label}</span></label>)}</div>;
}
