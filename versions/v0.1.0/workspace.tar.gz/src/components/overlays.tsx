import { cloneElement, useEffect, useId, useRef, useState, type ReactNode, type ReactElement, type HTMLAttributes, type KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { Button, Icon, IconButton, Kbd, cx, type IconName } from './primitives.js';
export interface DialogProps { open: boolean; onOpenChange: (open: boolean) => void; title: string; description?: string; children: ReactNode; footer?: ReactNode; className?: string; size?: 'sm' | 'md' | 'lg' }
export function Dialog({ open, onOpenChange, title, description, children, footer, className, size = 'md' }: DialogProps) {
  const ref = useRef<HTMLDialogElement>(null), id = useId();
  const change = useRef(onOpenChange); change.current = onOpenChange;
  useEffect(() => {
    const dialog = ref.current; if (!dialog) return;
    if (open && !dialog.open) {
      const previous = document.activeElement as HTMLElement | null;
      dialog.showModal();
      dialog.querySelector<HTMLElement>('[data-autofocus],input:not([disabled]),textarea:not([disabled]),select:not([disabled])')?.focus();
      return () => { dialog.close(); if (previous?.isConnected) previous.focus(); };
    }
  }, [open]);
  if (typeof document === 'undefined') return null;
  return createPortal(<dialog ref={ref} className={cx('cap-dialog', className)} data-size={size} aria-labelledby={`${id}-title`} aria-describedby={description ? `${id}-description` : undefined} onCancel={e => { e.preventDefault(); change.current(false); }} onKeyDown={e => {
    if (e.key !== 'Tab' || e.defaultPrevented) return;
    const focusable = Array.from(e.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex="-1"])')).filter(el => el.tabIndex >= 0 && el.getClientRects().length > 0);
    if (e.shiftKey && document.activeElement === focusable[0]) { e.preventDefault(); focusable.at(-1)?.focus(); }
    else if (!e.shiftKey && document.activeElement === focusable.at(-1)) { e.preventDefault(); focusable[0]?.focus(); }
  }} onClick={e => {
    if (e.target !== e.currentTarget) return;
    const rect = e.currentTarget.getBoundingClientRect();
    if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) change.current(false);
  }}><div className="cap-dialog-header"><div><h2 id={`${id}-title`}>{title}</h2>{description && <p id={`${id}-description`}>{description}</p>}</div><IconButton variant="ghost" icon="close" label="Закрыть" onClick={() => change.current(false)} /></div><div className="cap-dialog-body">{children}</div>{footer && <div className="cap-dialog-footer">{footer}</div>}</dialog>, document.body);
}
export function Tooltip({ content, children }: { content: string; children: ReactElement<{ 'aria-describedby'?: string }> }) {
  const [dismissed, setDismissed] = useState(false), id = useId();
  return <span className="cap-tooltip-wrap" onMouseEnter={() => setDismissed(false)} onFocus={() => setDismissed(false)} onKeyDown={e => { if (e.key === 'Escape') setDismissed(true); }}>{cloneElement(children, { 'aria-describedby': [children.props['aria-describedby'], !dismissed && id].filter(Boolean).join(' ') || undefined })}{!dismissed && <span id={id} role="tooltip" className="cap-tooltip">{content}</span>}</span>;
}
export interface MenuItem { id: string; label: string; icon?: IconName; shortcut?: string; disabled?: boolean; danger?: boolean; separator?: boolean; onSelect?: () => void }
export function Menu({ label, items, icon = 'more' }: { label: string; items: MenuItem[]; icon?: IconName }) {
  const [open, setOpen] = useState(false), root = useRef<HTMLDivElement>(null), trigger = useRef<HTMLButtonElement>(null), id = useId();
  const [position, setPosition] = useState({ left: 0, top: 0 });
  const startAtEnd = useRef(false);
  const buttons = () => Array.from(root.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)') ?? []);
  const close = (restore = true) => { setOpen(false); if (restore) trigger.current?.focus(); };
  useEffect(() => {
    if (!open) return;
    (startAtEnd.current ? buttons().at(-1) : buttons()[0])?.focus();
    const anchor = trigger.current?.getBoundingClientRect();
    const menu = document.getElementById(id)?.getBoundingClientRect();
    if (anchor && menu) setPosition({ left: Math.max(8, Math.min(anchor.right - menu.width, window.innerWidth - menu.width - 8)), top: anchor.bottom + menu.height + 8 > window.innerHeight ? Math.max(8, anchor.top - menu.height - 4) : anchor.bottom + 4 });
    const listener = (e: PointerEvent) => { if (!root.current?.contains(e.target as Node)) setOpen(false); };
    const reposition = (e: Event) => { if (!(e.target instanceof Node) || !document.getElementById(id)?.contains(e.target)) setOpen(false); };
    document.addEventListener('pointerdown', listener);
    window.addEventListener('resize', reposition);
    window.addEventListener('scroll', reposition, true);
    return () => { document.removeEventListener('pointerdown', listener); window.removeEventListener('resize', reposition); window.removeEventListener('scroll', reposition, true); };
  }, [open, id]);
  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); return; }
    if (e.key === 'Tab') { close(false); return; }
    const choices = buttons(), current = choices.indexOf(document.activeElement as HTMLButtonElement);
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) {
      e.preventDefault(); const i = e.key === 'Home' ? 0 : e.key === 'End' ? choices.length - 1 : (current + (e.key === 'ArrowDown' ? 1 : -1) + choices.length) % choices.length;
      choices[i]?.focus();
    } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) {
      choices.find(b => b.textContent?.toLowerCase().startsWith(e.key.toLowerCase()))?.focus();
    }
  };
  return <div ref={root} className="cap-menu-root" onBlur={e => { if (!e.currentTarget.contains(e.relatedTarget)) setOpen(false); }}><IconButton ref={trigger} label={label} icon={icon} variant="ghost" aria-haspopup="menu" aria-expanded={open} aria-controls={open ? id : undefined} onClick={() => { startAtEnd.current = false; setOpen(!open); }} onKeyDown={e => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); startAtEnd.current = e.key === 'ArrowUp'; setOpen(true); } }} />{open && <div role="menu" aria-label={label} id={id} className="cap-menu" style={position} onKeyDown={onKeyDown}>{items.map(item => <div key={item.id} role="none">{item.separator && <hr className="cap-separator" />}<button type="button" role="menuitem" className="cap-menu-item" tabIndex={-1} data-danger={item.danger || undefined} disabled={item.disabled} onClick={() => { close(); item.onSelect?.(); }}>{item.icon && <Icon name={item.icon} />}<span>{item.label}</span>{item.shortcut && <Kbd>{item.shortcut}</Kbd>}</button></div>)}</div>}</div>;
}
export function Popover({ label, children }: { label: string; children: ReactNode }) {
  const id = useId();
  const trigger = useRef<HTMLButtonElement>(null), panel = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState<{ left: number; top: number }>();
  return <span className="cap-popover-root"><Button ref={trigger} popoverTarget={id}>{label}<Icon name="down" size={12} /></Button><div ref={panel} id={id} popover="auto" className="cap-popover" style={position ? { ...position, margin: 0 } : undefined} onToggle={() => {
    if (!panel.current?.matches(':popover-open')) return;
    const anchor = trigger.current!.getBoundingClientRect(), rect = panel.current.getBoundingClientRect();
    setPosition({ left: Math.max(8, Math.min(anchor.left, window.innerWidth - rect.width - 8)), top: anchor.bottom + rect.height + 8 > window.innerHeight ? Math.max(8, anchor.top - rect.height - 6) : anchor.bottom + 6 });
  }}>{children}</div></span>;
}
export interface CommandItem { id: string; label: string; description?: string; icon?: IconName; shortcut?: string; onSelect: () => void }
export function CommandPalette({ open, onOpenChange, items, placeholder = 'Найти команду или объект…' }: { open: boolean; onOpenChange: (open: boolean) => void; items: CommandItem[]; placeholder?: string }) {
  const [query, setQuery] = useState(''), [active, setActive] = useState(0), id = useId();
  const input = useRef<HTMLInputElement>(null);
  const filtered = items.filter(i => `${i.label} ${i.description ?? ''}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()));
  useEffect(() => { if (open) { setQuery(''); setActive(0); input.current?.focus(); } }, [open]);
  const choose = (item: CommandItem) => { onOpenChange(false); item.onSelect(); };
  const index = Math.min(active, Math.max(0, filtered.length - 1));
  useEffect(() => { if (open) document.getElementById(`${id}-${index}`)?.scrollIntoView?.({ block: 'nearest' }); }, [id, index, open]);
  return <Dialog open={open} onOpenChange={onOpenChange} title="Быстрый поиск" className="cap-command" footer={<span className="cap-command-help"><Kbd>↑↓</Kbd> навигация <Kbd>↵</Kbd> выбрать <Kbd>esc</Kbd> закрыть</span>}><div className="cap-command-input"><Icon name="search" size={20} /><input ref={input} autoFocus role="combobox" aria-label="Поиск команд" aria-expanded={true} aria-controls={`${id}-list`} aria-autocomplete="list" aria-activedescendant={filtered.length ? `${id}-${index}` : undefined} value={query} placeholder={placeholder} onChange={e => { setQuery(e.target.value); setActive(0); }} onKeyDown={e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); setActive(filtered.length ? (index + (e.key === 'ArrowDown' ? 1 : -1) + filtered.length) % filtered.length : 0); }
    if (e.key === 'Enter' && !e.nativeEvent.isComposing && filtered[index]) { e.preventDefault(); choose(filtered[index]); }
  }} /></div><div id={`${id}-list`} role="listbox" aria-label="Результаты поиска" className="cap-command-list">{filtered.map((item, i) => <div key={item.id} id={`${id}-${i}`} role="option" aria-selected={i === index} className="cap-command-item" onPointerMove={() => setActive(i)} onMouseDown={e => e.preventDefault()} onClick={() => choose(item)}>{item.icon && <Icon name={item.icon} />}<span>{item.label}{item.description && <small>{item.description}</small>}</span>{item.shortcut && <Kbd>{item.shortcut}</Kbd>}</div>)}</div>{!filtered.length && <p className="cap-command-empty" role="status">Ничего не найдено</p>}</Dialog>;
}
export function Toast({ title, description, onDismiss, className, ...props }: HTMLAttributes<HTMLDivElement> & { title: string; description?: string; onDismiss?: () => void }) {
  return <div className={cx('cap-toast', className)} role="status" {...props}><Icon name="check" /><div><strong>{title}</strong>{description && <p>{description}</p>}</div>{onDismiss && <IconButton label="Скрыть уведомление" icon="close" size="sm" variant="ghost" onClick={onDismiss} />}</div>;
}
