// Development-only audit surface. Never included in production builds.
import axe from 'axe-core';
const button = document.createElement('button');
button.textContent = 'Run accessibility audit';
button.dataset.testid = 'run-audit';
button.style.cssText = 'position:fixed;bottom:0;left:0;z-index:1000;font:12px system-ui;background:#fff;color:#000;padding:4px;border:1px solid #000';
document.body.append(button);
const result = document.createElement('pre'); result.id = 'audit-result'; result.hidden = true; document.body.append(result);
button.onclick = async () => {
  result.textContent = '';
  const data = await axe.run(document.querySelector('dialog[open]') ?? document.querySelector('#root')!);
  result.textContent = JSON.stringify({ url: location.hash, theme: document.documentElement.dataset.theme, violations: data.violations.map(v => ({ id: v.id, impact: v.impact, description: v.description, nodes: v.nodes.map(n => ({ target: n.target, summary: n.failureSummary })) })) });
};
