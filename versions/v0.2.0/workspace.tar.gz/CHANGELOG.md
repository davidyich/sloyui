# Changelog

## 0.2.0 — 2026-10-04

- Preserved the complete 0.1.0 workspace and original npm package with SHA-256 checksums.
- Replaced the default color model with 12 neutral steps, 12 shared accent steps in 18 modes, and 24 Light/Dark semantic roles. Added Figma Variables graph and rollback-safe development importer.
- Replaced visible system Select/Popover surfaces with custom overlays. Added Drawer, scoped theme/accent inheritance, focus/inert/scroll locking, nested overlays, and enter/exit motion.
- Added ScrollArea, ButtonGroup, SplitButton, ActionBar, FloatingActionBar, FloatingField, StatusBar, Alert, SidebarPanel.
- Added Calendar, DatePicker, DailyHeader, MarkdownEditor/Preview, configurable ContentCard/TaskCard and controlled KanbanBoard/Column.
- Added pill Tabs, accent Button, inherited accent primitives and global state/motion/responsive contracts.
- Expanded the catalogue, 59-component agent manifest, working consumer example, package validation, keyboard and accessibility coverage.
