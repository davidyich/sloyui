---
version: alpha
name: Capacities UI
description: Independent reconstruction for personal object-oriented interfaces.
colors:
  bg-back: "#f0f0f0"
  bg-base: "#fafafa"
  bg-front: "#ffffff"
  bg-el: "#e5e5e5"
  bg-el-subtle: "#fafafa"
  bg-button-primary: "#343434"
  text-primary: "#242424"
  text-secondary: "#525252"
  text-subtle: "#666666"
  text-button-primary: "#ffffff"
  border-base: "#e5e5e5"
  border-front: "#e5e5e5"
typography:
  sans:
    fontFamily: Inter
  code:
    fontFamily: Overpass Mono
  xxs:
    fontFamily: Inter
    fontSize: ".6875rem"
    lineHeight: ".875rem"
  xs:
    fontFamily: Inter
    fontSize: ".75rem"
    lineHeight: "1rem"
  sm:
    fontFamily: Inter
    fontSize: ".84375rem"
    lineHeight: "1.2rem"
  base:
    fontFamily: Inter
    fontSize: ".9375rem"
    lineHeight: "1.325rem"
  lg:
    fontFamily: Inter
    fontSize: "1.125rem"
    lineHeight: "1.625rem"
  xl:
    fontFamily: Inter
    fontSize: "1.25rem"
    lineHeight: "1.75rem"
  2xl:
    fontFamily: Inter
    fontSize: "1.5rem"
    lineHeight: "2rem"
  3xl:
    fontFamily: Inter
    fontSize: "1.875rem"
    lineHeight: "2.25rem"
rounded:
  small: "0.3rem"
  base: "0.5rem"
  xl: "0.75rem"
  2xl: "1rem"
spacing:
  base: "0.25rem"
components:
  button-primary:
    backgroundColor: "{colors.bg-button-primary}"
    textColor: "{colors.text-button-primary}"
    rounded: "{rounded.base}"
    typography: "{typography.sm}"
  panel:
    backgroundColor: "{colors.bg-base}"
    rounded: "{rounded.xl}"
---

## Overview

Реконструированный дизайн для интерфейсов с коллекциями объектов. Разделяйте боковую навигацию и основное содержимое поверхностями. Используйте компактные строки, цветные обозначения типов и теги.

## Colors

Различайте фоновый слой, основную панель и всплывающую поверхность с помощью ролей back, base и front. Primary-кнопка использует нейтральную инверсию текста и фона. Цветовые семейства применяйте к типам объектов, тегам и содержимому информационных блоков.

## Themes

V2 использует чистый grayscale. Light/Dark независимы от локального Accent. Две оси воспроизводятся в CSS через data-theme/data-accent, в Figma через collections Appearance/Accent. Neutral хранит 12 фиксированных ступеней, Accent — 12 общих Variables в 18 модах, Appearance — 24 роли в Light/Dark. Всего 48 Variables.

| Role | Light | Dark |
| --- | --- | --- |
| surface-canvas | #f0f0f0 | #101010 |
| surface-base | #fafafa | #181818 |
| surface-raised | #ffffff | #242424 |
| content-primary | #242424 | #fafafa |
| content-muted | #666666 | #a3a3a3 |
| border-default | #e5e5e5 | #343434 |
| action-solid | #343434 | #e5e5e5 |

Акцентные роли soft/bg/block/border/text/ink/solid/solid-hover/on-solid ссылаются на выбранную шкалу. Не создавайте отдельный semantic token для каждого оттенка. Статусы success/warning/danger/info имеют фиксированный смысл и не меняются вместе с цветом объекта.

## Typography

Используйте sans для элементов интерфейса и code для фрагментов кода. Для обычных контролов применяйте шкалу sm, для основного текста — base. Заголовки отделяйте размером и весом; метаданные оформляйте меньшей шкалой.

## Layout

Стройте отступы от базового spacing. Располагайте действия строки справа, тип объекта — слева от названия. Длинные списки сохраняйте прокручиваемыми и доступными с клавиатуры.

## Elevation & Depth

Отделяйте панели тонкой границей. Добавляйте тень всплывающим меню и диалогам. Для обычных карточек используйте границу и изменение поверхности при наведении.

## Shapes

Используйте small для тегов и компактных обозначений, base для кнопок и полей, xl для карточек и панелей. Иконки типов оформляйте через IconBox.

## Components

Стройте формы через Field или FloatingField и контролы набора. Select/Popover/Dialog/Drawer имеют собственные поверхности; hidden native Select сохраняет HTML-форму. Для операций над объектом используйте ObjectCard или CollectionRow; для неинтерактивных групп — Card. Поддерживайте состояния загрузки, недоступности, ошибки и пустого результата. Для мелких читаемых подписей используйте доступную роль text-muted набора.

## Motion and responsive behavior

Общий контракт — `docs/behavior.md`: 120/180/260 ms, opacity/transform, reduced motion, 12 px viewport gutter, 44 px touch targets. ScrollArea ограничивает scroll локальным контейнером и показывает внутренние тени по реальному overflow.
