import { useState, type ReactNode } from 'react';
import { Badge, Button, Icon, IconBox, IconButton, Kbd } from '../src/components/primitives';
import { Field, Input, Select, Switch, Textarea } from '../src/components/forms';
import { Dialog, Drawer, Menu, Popover, Tooltip } from '../src/components/overlays';

function Example({ title, description, children }: { title: string; description: string; children: ReactNode }) {
  return <section className="example"><div className="example-heading"><div><h2>{title}</h2><p>{description}</p></div></div><div className="example-stage" style={{ minHeight: 160, display: 'grid', alignContent: 'start', gap: 16 }}>{children}</div></section>;
}
export function OverlaysV2() {
  const [dialog, setDialog] = useState(false), [drawer, setDrawer] = useState(false), [nested, setNested] = useState(false), [accent, setAccent] = useState('rose'), [message, setMessage] = useState('Изменения сохранены локально');
  return <div className="overlays-v2-showcase">
    <header className="page-intro"><div className="eyebrow">КОМПОНЕНТЫ / OVERLAYS</div><h1>Поверх интерфейса</h1><p>Меню, подсказки и окна с небольшими отступами от краёв. Единые поверхности, плавные переходы и предсказуемая работа с клавиатурой.</p></header>
    <div className="example-grid">
      <Example title="Окно и боковая панель" description="Затенение фона, собственная прокрутка и возврат фокуса после закрытия.">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}><IconBox icon="page" color="neutral" /><div><strong style={{ fontWeight: 500 }}>Место для важного действия</strong><p className="muted" style={{ fontSize: 12, lineHeight: 1.5, margin: '4px 0 0' }}>Создайте заметку или измените свойства коллекции.</p></div></div>
        <div className="demo-row"><Button variant="primary" onClick={() => setDialog(true)}>Открыть окно</Button><Button onClick={() => setDrawer(true)}>Боковая панель</Button></div>
      </Example>
      <Example title="Меню и подсказки" description="Пункты с иконками, разделителями и горячими клавишами. Подсказки доступны при фокусе.">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', border: '1px solid var(--cap-border-base)', borderRadius: 10, background: 'var(--cap-bg-back)' }}><Icon name="page" /><span style={{ flex: 1, minWidth: 0 }}>Идеи для проекта</span><Menu label="Действия с объектом" items={[{ id: 'remove', label: 'Убрать из коллекции', icon: 'close', onSelect: () => setMessage('Объект убран из коллекции') }, { id: 'type', label: 'Изменить тип', icon: 'layers', separator: true, onSelect: () => setDrawer(true) }, { id: 'copy', label: 'Копировать', icon: 'copy', shortcut: '⌘ C', separator: true, onSelect: () => setMessage('Копия объекта готова') }, { id: 'duplicate', label: 'Дублировать', icon: 'page', onSelect: () => setMessage('Создан дубликат объекта') }, { id: 'delete', label: 'Удалить объект', icon: 'trash', danger: true, onSelect: () => setMessage('Объект помещён в корзину') }]} /></div>
        <div className="demo-row"><Tooltip content="Режим фокуса" shortcut={['⇧', '⌘', 'M']}><IconButton label="Режим фокуса" icon="sun" onClick={() => setMessage('Режим фокуса включён для примера')} /></Tooltip><span className="muted" style={{ fontSize: 12 }}>Наведите курсор или перейдите клавишей Tab</span></div>
      </Example>
      <Example title="Настройки рядом с элементом" description="Попап привязан к кнопке и меняет положение, когда рядом с краем не хватает места.">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}><IconBox icon="grid" color="neutral" /><div><strong style={{ fontWeight: 500 }}>Коллекция заметок</strong><p className="muted" style={{ fontSize: 12, margin: '4px 0 0' }}>Свойства, обложки и плотность карточек</p></div></div>
        <div className="demo-row"><Popover label="Настройки вида"><div style={{ display: 'grid', gap: 16 }}><strong>Карточки коллекции</strong><Switch label="Показывать свойства" defaultChecked /><Switch label="Показывать обложки" defaultChecked /><Field label="Плотность">{props => <Select {...props} defaultValue="normal" options={[{ value: 'compact', label: 'Компактная' }, { value: 'normal', label: 'Обычная' }, { value: 'comfortable', label: 'Свободная' }]} />}</Field></div></Popover><Badge variant="outline">28 объектов</Badge></div>
      </Example>
      <Example title="Локальный акцент" description="Выберите режим: элемент и его всплывающее содержимое сохранят один акцент.">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, alignItems: 'end' }}><Field label="Локальный акцент">{props => <Select {...props} value={accent} onValueChange={setAccent} options={[{ value: 'rose', label: 'Rose' }, { value: 'blue', label: 'Blue' }, { value: 'teal', label: 'Teal' }, { value: 'neutral', label: 'Neutral' }]} />}</Field><div data-accent={accent}><Popover label="Попап наследует акцент"><div style={{ display: 'grid', gap: 12 }}><strong>Локальная тема элемента</strong><p style={{ margin: 0, color: 'var(--cap-text-muted)', lineHeight: 1.5 }}>Всплывающая поверхность сохраняет режим акцента своего триггера.</p><Button variant="primary" onClick={() => setMessage(`Акцент ${accent} применён`)}>Применить акцент</Button></div></Popover></div></div>
        <div data-accent={accent} style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Badge>{accent}</Badge><span className="muted" style={{ fontSize: 12 }}>Одна структура · разные режимы</span></div>
      </Example>
    </div>
    <div style={{ display: 'grid', gap: 14, marginTop: 24 }}><p role="status" style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--cap-text-muted)', margin: 0, fontSize: 12 }}><Icon name="check" size={14} />{message}</p><div className="demo-row muted" style={{ fontSize: 11, gap: '10px 18px' }}><span><Kbd>Esc</Kbd> закрыть верхнее окно</span><span><Kbd>Tab</Kbd> перейти к следующему элементу</span><span><Kbd>↑↓</Kbd> выбрать пункт</span></div></div>
    <Dialog open={dialog} onOpenChange={setDialog} title="Новая заметка" description="Небольшое окно с фиксированными шапкой и панелью действий." footer={<><Button variant="ghost" onClick={() => setDialog(false)}>Отмена</Button><Button variant="primary" onClick={() => { setMessage('Заметка сохранена'); setDialog(false); }}>Сохранить</Button></>}>
      <div style={{ display: 'grid', gap: 16 }}><Field label="Название">{props => <Input {...props} placeholder="Например, идеи для проекта" />}</Field><Field label="Тип">{props => <Select {...props} defaultValue="note"><option value="note">Заметка</option><option value="task">Задача</option><option value="project">Проект</option></Select>}</Field><Field label="Содержание">{props => <Textarea {...props} rows={5} placeholder="Начните писать…" />}</Field><Button variant="outline" onClick={() => setNested(true)}>Открыть вложенную панель</Button></div>
      <Drawer open={nested} onOpenChange={setNested} title="Свойства заметки" size="sm"><Field label="Автор">{props => <Input {...props} defaultValue="Вы" />}</Field></Drawer>
    </Dialog>
    <Drawer open={drawer} onOpenChange={setDrawer} title="Настройки коллекции" description="Панель сохраняет 12 px до края окна." footer={<Button variant="primary" onClick={() => { setMessage('Настройки коллекции сохранены'); setDrawer(false); }}>Готово</Button>}>
      <div style={{ display: 'grid', gap: 18 }}><Field label="Название">{props => <Input {...props} defaultValue="Личные проекты" />}</Field><Field label="Представление">{props => <Select {...props} defaultValue="board" options={[{ value: 'board', label: 'Канбан' }, { value: 'list', label: 'Список' }, { value: 'grid', label: 'Сетка' }]} />}</Field><Switch label="Показывать завершённые" /><Switch label="Группировать по статусу" defaultChecked /></div>
    </Drawer>
  </div>;
}
