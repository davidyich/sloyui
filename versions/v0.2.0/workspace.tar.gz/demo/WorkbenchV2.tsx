import { useState, type ReactNode } from 'react';
import { Avatar, Badge, Button, Icon, IconButton, Kbd, TypeLabel } from '../src/components/primitives.js';
import { SidebarItem } from '../src/components/layout.js';
import { Popover, Tooltip } from '../src/components/overlays.js';
import { ActionBar, Alert, ButtonGroup, FloatingActionBar, FloatingField, ScrollArea, SidebarPanel, SplitButton, StatusBar } from '../src/components/workbench.js';

function Example({ title, description, children, wide }: { title: string; description: string; children: ReactNode; wide?: boolean }) {
  return <section className={`example${wide ? ' example-wide' : ''}`}><div className="example-heading"><div><h2>{title}</h2><p>{description}</p></div></div><div className="example-stage">{children}</div></section>;
}
const originalNotes = [
  'Небольшие ежедневные ритуалы', 'Идеи для нового проекта', 'Список прочитанных книг', 'Планы на следующую неделю',
  'Что помогает сосредоточиться', 'Интересные места рядом', 'Заметки о дизайне', 'Сохранённые ссылки',
  'Прототип домашней страницы', 'Встреча с командой', 'Исследование интерфейсов', 'Референсы для коллекции',
];
export default function WorkbenchV2() {
  const [notes, setNotes] = useState(originalNotes), [query, setQuery] = useState(''), [sort, setSort] = useState(false);
  const [compact, setCompact] = useState(false), [onlyNew, setOnlyNew] = useState(false), [active, setActive] = useState('Проекты');
  const [fieldValue, setFieldValue] = useState(''), [submitted, setSubmitted] = useState(false), [savedName, setSavedName] = useState('');
  const [warning, setWarning] = useState(true), [paused, setPaused] = useState(false), [sidebarTheme, setSidebarTheme] = useState<'light' | 'dark'>('light');
  const [edges, setEdges] = useState('В начале списка');
  const add = (kind: string) => { setNotes(current => [...current, `${kind} ${current.length + 1}`]); setQuery(''); setOnlyNew(false); };
  const visible = notes.filter(note => note.toLocaleLowerCase().includes(query.toLocaleLowerCase()) && (!onlyNew || !originalNotes.includes(note)));
  const ordered = sort ? [...visible].sort((a, b) => a.localeCompare(b, 'ru')) : visible;
  return <><header className="page-intro"><div className="eyebrow">КОМПОНЕНТЫ / WORKBENCH</div><h1>Небольшие рабочие детали</h1><p>Составные действия, панели, поля и прокрутка. Все примеры реагируют на действия и работают с клавиатурой.</p></header>
    <div className="example-grid">
      <Example wide title="Составная панель коллекции" description="Группы с общей рамкой, счётчик, меню и основное действие с дополнительными вариантами.">
        <div style={{ width: '100%', minWidth: 0 }}>
          <div className="demo-row" style={{ justifyContent: 'space-between', gap: 12, marginBottom: 12 }}>
            <ButtonGroup label="Вид коллекции" prefix={visible.length}>
              <Tooltip content="Показать только новые"><IconButton label="Только новые заметки" icon="filter" variant="ghost" aria-pressed={onlyNew} onClick={() => setOnlyNew(value => !value)} /></Tooltip>
              <IconButton label="Сортировать по названию" icon="list" variant="ghost" aria-pressed={sort} onClick={() => setSort(value => !value)} />
              <IconButton label="Компактный вид" icon="grid" variant="ghost" aria-pressed={compact} onClick={() => setCompact(value => !value)} />
            </ButtonGroup>
            <div className="demo-row" style={{ gap: 8 }}>
              <Popover label="Поиск"><FloatingField label="Найти заметку" leading={<Icon name="search" />} value={query} onChange={event => setQuery(event.target.value)} /></Popover>
              <SplitButton label="Создать" leading={<Icon name="plus" />} onClick={() => add('Заметка')} items={[
                { id: 'note', label: 'Новая заметка', icon: 'page', onSelect: () => add('Заметка') },
                { id: 'project', label: 'Новый проект', icon: 'cube', onSelect: () => add('Проект') },
                { id: 'collection', label: 'Новая коллекция', icon: 'folder', separator: true, onSelect: () => add('Коллекция') },
              ]} />
            </div>
          </div>
          <ScrollArea label="Заметки коллекции" style={{ height: 224, border: '1px solid var(--cap-border-base)', borderRadius: 'var(--cap-radius-xl)' }} onEdgesChange={state => setEdges(state.top ? state.bottom ? 'В середине списка' : 'В конце списка' : 'В начале списка')}>
            <div style={{ padding: 8, display: 'grid', gap: compact ? 2 : 8 }}>
              {ordered.map(note => <div key={note} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: compact ? '7px 8px' : '12px 8px', borderRadius: 'var(--cap-radius-base)', background: 'var(--cap-bg-back)', fontSize: 'var(--cap-font-size-sm)' }}><Icon name="page" /><span>{note}</span>{!originalNotes.includes(note) && <Badge color="blue">Новое</Badge>}</div>)}
              {!ordered.length && <p className="muted" style={{ padding: 16 }}>{onlyNew ? 'Создайте первую заметку кнопкой выше.' : 'По этому запросу заметок нет.'}</p>}
            </div>
          </ScrollArea>
          <StatusBar trailing={<span>{edges}</span>}>{visible.length} из {notes.length} объектов</StatusBar>
        </div>
      </Example>
      <Example title="Плавающая панель в боковом меню" description="Панель с отступом от краёв. Tab входит в группу, стрелки перемещают фокус между действиями.">
        <SidebarPanel label="Личное пространство" data-theme={sidebarTheme} style={{ height: 320 }} width="100%" header={<strong>Личное пространство</strong>} footer={
          <FloatingActionBar label="Действия пространства" position="static">
            <Tooltip content="Перейти к профилю"><IconButton label="Профиль" icon="heart" variant="ghost" onClick={() => setActive('Профиль')} /></Tooltip>
            <Button variant="ghost" leading={<Avatar name="Анна" size="xs" />} onClick={() => setActive('Профиль')}>Анна</Button>
            <Tooltip content="Изменить тему панели"><IconButton label="Изменить тему панели" icon={sidebarTheme === 'light' ? 'moon' : 'sun'} variant="ghost" onClick={() => setSidebarTheme(value => value === 'light' ? 'dark' : 'light')} /></Tooltip>
            <IconButton label="Настройки пространства" icon="settings" variant="ghost" onClick={() => setActive('Настройки')} />
          </FloatingActionBar>
        }>
          <nav aria-label="Разделы пространства">{(['Проекты', 'Заметки', 'Люди', 'Книги', 'Профиль', 'Настройки'] as const).map((title, index) => <SidebarItem key={title} icon={(['cube', 'page', 'heart', 'book', 'heart', 'settings'] as const)[index]} active={active === title} onClick={() => setActive(title)}>{title}</SidebarItem>)}</nav>
          <div style={{ padding: '12px 8px' }}><TypeLabel icon="folder" color="purple">{active}</TypeLabel></div>
        </SidebarPanel>
      </Example>
      <Example title="Лейбл внутри поля" description="Подпись остаётся видимой после ввода. Ошибка связана с полем и объявляется скринридером.">
        <form style={{ display: 'grid', gap: 16, width: '100%' }} onSubmit={event => { event.preventDefault(); setSubmitted(true); if (fieldValue.trim()) setSavedName(fieldValue.trim()); }} noValidate>
          <FloatingField label="Название коллекции" required leading={<Icon name="folder" />} value={fieldValue} onChange={event => { setFieldValue(event.target.value); setSubmitted(false); setSavedName(''); }} error={submitted && !fieldValue.trim() ? 'Введите название коллекции.' : undefined} hint="Название можно будет изменить позже." />
          <FloatingField label="Владелец" defaultValue="Личное пространство" disabled />
          <Button variant="primary" type="submit">Сохранить коллекцию</Button>
          {savedName && <StatusBar tone="success">Коллекция «{savedName}» сохранена в этом примере.</StatusBar>}
        </form>
      </Example>
      <Example wide title="Статусы и раскрывающиеся уведомления" description="Общий язык состояний: цвет, пиктограмма, текст. Длинные подробности раскрываются внутри контейнера.">
        <div style={{ display: 'grid', gap: 12, width: '100%' }}>
          <Alert tone="success" title="Все изменения сохранены на устройстве" expandable defaultExpanded>Данные этого примера находятся в текущей сессии. Теперь можно продолжить работу или переключиться на другой раздел.</Alert>
          <Alert tone="info" title="Как устроена прокрутка" expandable>Тени появляются только там, где есть скрытое содержимое. Наведите указатель на список выше или переведите в него фокус клавишей Tab и используйте стрелки.</Alert>
          {warning ? <Alert tone="warning" title="Изменения ещё не отправлены" onDismiss={() => setWarning(false)}>Проверьте поля перед сохранением. Это уведомление можно закрыть.</Alert> : <Button size="sm" variant="ghost" onClick={() => setWarning(true)}>Показать предупреждение</Button>}
          <StatusBar tone={paused ? 'warning' : 'success'} trailing={<Button size="xs" variant="ghost" onClick={() => setPaused(value => !value)}>{paused ? 'Продолжить' : 'Приостановить'}</Button>}>{paused ? 'Синхронизация примера приостановлена' : 'Все изменения в примере сохранены'}</StatusBar>
        </div>
      </Example>
      <Example wide title="Горизонтальная прокрутка и быстрые действия" description="Край списка подсказывает продолжение. Фокус и элементы не скрываются под декоративными тенями.">
        <div style={{ width: '100%', minWidth: 0 }}><ScrollArea axis="horizontal" label="Категории коллекции" style={{ maxWidth: '100%' }}>
          <ActionBar label="Категории" style={{ flexWrap: 'nowrap', padding: '8px 4px' }}>
            {['Все', 'Сегодня', 'Запланировано', 'В процессе', 'Открыто', 'Завершено', 'Теги', 'Дедлайны', 'Повторяющиеся'].map(item => <Button key={item} variant={active === item ? 'secondary' : 'ghost'} aria-pressed={active === item} onClick={() => setActive(item)}>{item}</Button>)}
          </ActionBar>
        </ScrollArea><p className="muted" style={{ margin: '12px 4px 0', fontSize: 'var(--cap-font-size-xs)' }}>Выбрано: {active}. <Kbd>←</Kbd> <Kbd>→</Kbd> — переход между действиями.</p></div>
      </Example>
    </div>
  </>;
}
