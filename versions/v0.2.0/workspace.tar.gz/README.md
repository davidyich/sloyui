# Capacities UI · V2

Лёгкий UI-kit для персональных проектов: **59 компонентов**, React 19+, TypeScript и обычный CSS. Две темы, локальные акцентные моды, собственные всплывающие поверхности. Runtime-зависимостей кроме React/React DOM нет.

## Каталог

```sh
npm ci
npm run dev
```

Открыть http://127.0.0.1:4317/. Цвета, размеры, типографика, состояния, формы, окна, скролл, календарь, Markdown и канбан — в одном интерактивном каталоге. `Cmd/Ctrl+K` открывает поиск. Данные примеров хранятся в памяти страницы.

## Подключение

```sh
npm run pack:kit
```

В своём проекте установите локальный `artifacts/personal-capacities-ui-0.2.0.tgz` командой `npm install /absolute/path/to/personal-capacities-ui-0.2.0.tgz`. Пакет пока не опубликован в публичном npm.

```tsx
import { Button, Tag, FloatingField, ScrollArea } from '@personal/capacities-ui';
import '@personal/capacities-ui/styles.css';
import '@personal/capacities-ui/fonts.css'; // optional local Inter + Overpass Mono

export function Project() {
  return <section data-accent="teal">
    <Tag>В работе</Tag>
    <FloatingField label="Название проекта" />
    <Button variant="accent">Сохранить</Button>
    <ScrollArea label="Заметки" style={{ height: 240 }}>…</ScrollArea>
  </section>;
}
```

Задайте `data-theme="light"` или `data-theme="dark"` на `html`. По умолчанию — light. Переключение system theme и сохранение предпочтения принадлежат приложению. Локальные `data-theme` и `data-accent` наследуются popup и dialog через portal.

Стили ограничены классами `cap-`; `body` и раскладка приложения не сбрасываются. Для оболочки используйте `--cap-surface-canvas`, `--cap-content-primary`, `--cap-font-sans`.

## Цвета: небольшая общая модель

| Коллекция | Переменные | Моды |
| --- | ---: | --- |
| Neutral | 12 grayscale-ступеней | Base |
| Accent | 12 одинаковых имён `accent/1…12` | neutral + 17 цветов |
| Appearance | 24 роли фона, текста, границ и акцента | Light / Dark |

Всего **48 Variables**, без повторения имён ролей для каждого цвета. Light/Dark ссылается на ступени Neutral и выбранного Accent. Например, `accent/soft` в Light связан с `accent/1`, в Dark — с `accent/12`. Цветовые компоненты `Tag`, `Badge`, `TypeLabel`, `IconBox` без `color` наследуют мод контейнера. `color="rose"` или вложенный `data-accent="rose"` задаёт локальное переопределение. `gray` оставлен как совместимый псевдоним neutral.

`styles.css` содержит готовые токены и стили. Отдельный `tokens.css` нужен только для использования переменных без компонентов. Основные роли: `--cap-surface-base`, `--cap-content-muted`, `--cap-border-default`, `--cap-accent-soft`, `--cap-accent-ink`, `--cap-accent-solid`, `--cap-accent-on-solid`. Старые общие `--cap-bg-*`, `--cap-text-*`, `--cap-border-*` сохранены как алиасы. Старые роли каждого оттенка (`--cap-tag-bg-purple` и подобные) заменены общими accent-ролями.

Готовая модель Figma: [figma-modes.json](src/tokens/figma-modes.json). Импорт с реальными межколлекционными aliases: [инструкция](figma/README.md). CSS сохраняет исходные OKLCH акцентов, Figma получает sRGB. Neutral в V2 — чистый grayscale, а не точная копия тонированной шкалы V1.

## Компоненты

| Группа | Состав |
| --- | --- |
| Действия | Button, IconButton, ButtonGroup, SplitButton, ActionBar, FloatingActionBar, Menu, Tooltip, Popover |
| Формы | Field, Input, FloatingField, Textarea, Select, Checkbox, Radio, Switch, Slider, SegmentedControl, DatePicker |
| Панели | Dialog, Drawer, CommandPalette, SidebarPanel, ScrollArea |
| Контент | Calendar, DailyHeader, MarkdownEditor, MarkdownPreview, ContentCard, TaskCard, KanbanBoard, KanbanColumn |
| Навигация | SidebarItem, Breadcrumbs, Tabs (line/pills), Accordion |
| Объекты | Card, ObjectCard, CollectionRow, PropertyRow, Badge, Tag, TypeLabel, IconBox, Avatar |
| Обратная связь | StatusBar, Alert, Toast, Callout, EmptyState, Progress, Spinner, Skeleton |
| Основа | Icon, Kbd, Separator, Table, CodeBlock |

Button: `primary/secondary/outline/ghost/danger/accent`, размеры 22/28/32/36 px. Touch-контролы получают минимум 44 px. Радиусы 4.8/8/12/16 px. Inter 13.5 px для компактного UI, 15 px для основного текста; Overpass Mono для кода. Шрифты self-hosted и подключаются отдельно.

Диалоги, меню, Select и Popover имеют собственное оформление, отступ 12 px от viewport, клавиатуру, Escape и возврат фокуса. У Select нативный скрытый элемент сохраняет контракт HTML-формы; видимый список полностью custom. ScrollArea использует браузерную прокрутку с тонким scrollbar и тенями по доступным направлениям. Оболочка scrollbar может немного различаться между браузерами.

## Для агентов

Читайте [llms.txt](llms.txt), затем нужные записи [agent-manifest.json](agent-manifest.json). Примеры: [ProjectBoard](examples/ProjectBoard.tsx), [WorkspaceV2](examples/WorkspaceV2.tsx). [Content guide](docs/content-guide.md) описывает календарь, редактор и карточки. [Behavior](docs/behavior.md) закрепляет motion, состояния и адаптив. Размеры сборки измерены в [bundle-size.json](docs/bundle-size.json).

MarkdownEditor — редактор текста с безопасным preview документированного поднабора Markdown. Канбан использует доступное меню перемещения; drag-and-drop не реализован. Persistence, backend, загрузка вложений и полнофункциональный редактор Capacities остаются задачей приложения.

## Проверка и откат

```sh
npm run check
npm run pack:kit
npm run verify:package
```

`check` проверяет типы, поведение, модель токенов, сборку библиотеки и каталога. `verify:package` отдельно устанавливает архив в изолированный consumer, проверяет типы обоих примеров, SSR-импорт, шрифты и tree shaking. [Фактическая проверка](docs/verification.md).

**V1 сохранена без изменений** в [versions/v0.1.0](versions/v0.1.0/README.md): весь workspace и исходный npm-пакет, контрольные суммы и безопасная инструкция восстановления. Архивы не перезаписываются сборкой.

Современные браузеры с OKLCH, `color-mix()`, `light-dark()` и `inert`. Ручная проверка проведена в Chrome; она не заменяет проверку каждого браузера/скринридера. [Происхождение значений](docs/provenance.md), [лицензии](THIRD_PARTY_NOTICES.md).
