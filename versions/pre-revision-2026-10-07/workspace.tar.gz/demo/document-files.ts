export const documentFiles = [
 {path:'docs/overview.md',label:'overview.md'},
 {path:'docs/component-guidelines.md',label:'component-guidelines.md'},
 {path:'docs/anti-patterns.md',label:'anti-patterns.md'},
 {path:'docs/examples.md',label:'examples.md'},
 {path:'AGENTS.md',label:'AGENTS.md'},
 {path:'llms.txt',label:'llms.txt'},
 {path:'DESIGN.md',label:'DESIGN.md'},
 {path:'docs/recipes.md',label:'recipes.md'},
 {path:'docs/surface-context.md',label:'surface-context.md'},
 {path:'docs/behavior.md',label:'behavior.md'},
 {path:'docs/content-guide.md',label:'content-guide.md'},
] as const;
