import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import type { CSSProperties, PointerEvent as ReactPointerEvent, ReactNode } from 'react';
import { Button, Icon } from './primitives.js';
import { Toast, useOverlayPresence } from './overlays.js';
import { useDisclosurePresence, type DisclosurePhase } from './disclosure.js';

export interface ToastStackItem { id:string; title:string; description?:string; duration?:number; action?:{label:string;onAction:()=>void} }
export interface ToastStackProps { items:ToastStackItem[]; onDismiss:(id:string)=>void; position?:'top-left'|'top-center'|'top-right'|'bottom-left'|'bottom-center'|'bottom-right'|'inline'; label?:string; limit?:number; className?:string }

function TimedToast({item,onDismiss,paused,depth,expanded,position,phase}:{item:ToastStackItem;onDismiss:(id:string)=>void;paused:boolean;depth:number;expanded:boolean;position:ToastStackProps['position'];phase:DisclosurePhase}){
  const remaining=useRef(item.duration??5000),started=useRef(0);
  useEffect(()=>{if(phase==='exit'||item.action||item.duration===Infinity||paused||remaining.current<=0)return;started.current=performance.now();const timer=setTimeout(()=>onDismiss(item.id),remaining.current);return()=>{clearTimeout(timer);remaining.current=Math.max(0,remaining.current-(performance.now()-started.current))}},[item.id,item.duration,item.action,paused,onDismiss,phase]);
  const translate=expanded?0:((position?.startsWith('top')?1:-1)*depth*8);
  return <li className="cap-toast-stack-item" data-toast-id={item.id} data-depth={depth} data-phase={phase} data-expanded={expanded||undefined} data-has-action={item.action||undefined} aria-hidden={phase==='exit'||undefined} inert={phase==='exit'||depth>0&&!expanded} style={{'--cap-toast-depth':depth,'--cap-toast-shift':`${translate}px`} as CSSProperties}><Toast className={item.action?'cap-toast-stack-has-action':''} title={item.title} description={item.description} onDismiss={()=>onDismiss(item.id)}/>{item.action&&<Button className="cap-toast-stack-action" size="sm" variant="ghost" onClick={item.action.onAction}>{item.action.label}</Button>}</li>
}

export function ToastStack({items,onDismiss,position='bottom-right',label='Notifications',limit=4,className=''}:ToastStackProps){
  const [hovered,setHovered]=useState(false),[focused,setFocused]=useState(false),[hidden,setHidden]=useState(false);
  const listRef=useRef<HTMLOListElement>(null),[sizes,setSizes]=useState<Record<string,number>>({});
  useEffect(()=>{const change=()=>setHidden(document.hidden);document.addEventListener('visibilitychange',change);change();return()=>document.removeEventListener('visibilitychange',change)},[]);
  const shown=items.slice(-Math.max(1,limit)).reverse(),present=useDisclosurePresence(shown,item=>item.id),expanded=hovered||focused,paused=expanded||hidden;
  const signature=present.map(entry=>entry.key).join('\u0000');
  useLayoutEffect(()=>{
    if(position!=='inline'||!listRef.current)return;
    const nodes=Array.from(listRef.current.querySelectorAll<HTMLLIElement>('.cap-toast-stack-item'));
    const measure=()=>{const next=Object.fromEntries(nodes.map(node=>[node.dataset.toastId!,node.offsetHeight]));setSizes(previous=>Object.keys(next).length===Object.keys(previous).length&&Object.entries(next).every(([key,value])=>previous[key]===value)?previous:next)};
    measure();
    if(typeof ResizeObserver==='undefined')return;
    const observer=new ResizeObserver(measure);nodes.forEach(node=>observer.observe(node));return()=>observer.disconnect();
  },[position,signature]);
  const frontHeight=sizes[present[0]?.key]??0;
  const depthClearance=present.reduce((maximum,entry,index)=>Math.max(maximum,(sizes[entry.key]??frontHeight)*Math.max(.75,1-index*.035)+(position.startsWith('top')?index*8:-index*8)),frontHeight);
  const collapsedClearance=present.length?Math.ceil(depthClearance+Math.max(0,present.length-1)*8+8):0;
  const expandedClearance=present.reduce((total,entry)=>total+(sizes[entry.key]??frontHeight),0)+Math.max(0,present.length-1)*8;
  const inlineClearance=expanded?Math.max(collapsedClearance,expandedClearance):collapsedClearance;
  return <div className={`cap-toast-stack ${className}`} role="region" aria-label={label} data-position={position} data-expanded={expanded||undefined} onPointerEnter={e=>{if(e.pointerType==='mouse')setHovered(true)}} onPointerLeave={e=>{if(e.pointerType==='mouse')setHovered(false)}} onMouseEnter={()=>setHovered(true)} onMouseLeave={()=>setHovered(false)} onFocusCapture={()=>setFocused(true)} onBlurCapture={e=>{if(!e.currentTarget.contains(e.relatedTarget as Node|null))setFocused(false)}}><ol ref={listRef} className="cap-toast-stack-list" style={position==='inline'?{'--cap-toast-inline-clearance':`${inlineClearance}px`} as CSSProperties:undefined}>{present.map(({key,item,phase},i)=><TimedToast key={key} item={item} onDismiss={onDismiss} paused={paused} depth={i} expanded={expanded} position={position} phase={phase}/>)}</ol></div>
}

export interface AnnouncementAction { label:string; href?:string; onClick?:()=>void }
export interface Announcement { id:string; message:ReactNode; action?:AnnouncementAction; countdown?:{to:Date|string|number;label?:string} }
export interface AnnouncementBarProps { messages:Announcement[]; id?:string; open?:boolean; defaultOpen?:boolean; onOpenChange?:(open:boolean)=>void; index?:number; defaultIndex?:number; onIndexChange?:(index:number)=>void; interval?:number; autoPlay?:boolean; dismissible?:boolean; controls?:boolean; label?:string; onAction?:(message:Announcement)=>void; onCountdownEnd?:(message:Announcement)=>void; className?:string }
const announcementStorageKey=(id:string)=>`cap-announcement:${id}`;
function wasAnnouncementDismissed(id?:string){if(!id||typeof window==='undefined')return false;try{return window.localStorage.getItem(announcementStorageKey(id))==='1'}catch{return false}}
export function clearAnnouncementDismissal(id:string){if(typeof window==='undefined')return;try{window.localStorage.removeItem(announcementStorageKey(id))}catch{/* storage can be unavailable */}}
function countdownText(to:Date|string|number,now:number){const ms=Math.max(0,new Date(to).getTime()-now),s=Math.floor(ms/1000);return {ended:ms===0,text:`${Math.floor(s/86400)}d ${String(Math.floor(s%86400/3600)).padStart(2,'0')}:${String(Math.floor(s%3600/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`}}
export function AnnouncementBar({messages,id:persistenceId,open,defaultOpen=true,onOpenChange,index,defaultIndex=0,onIndexChange,interval=6000,autoPlay=true,dismissible=true,controls=false,label='Announcement',onAction,onCountdownEnd,className=''}:AnnouncementBarProps){
  const [innerOpen,setInnerOpen]=useState(()=>defaultOpen&&!wasAnnouncementDismissed(persistenceId)),[innerIndex,setInnerIndex]=useState(defaultIndex),[hovered,setHovered]=useState(false),[focused,setFocused]=useState(false),[manuallyPaused,setManuallyPaused]=useState(false),[hidden,setHidden]=useState(false),[now,setNow]=useState(Date.now());
  const isOpen=open??innerOpen,active=Math.max(0,Math.min(messages.length-1,index??innerIndex)),message=messages[active],domId=useId(),endCalled=useRef(new Set<string>()),lastMessage=useRef<Announcement|undefined>(message),paused=hovered||focused||manuallyPaused||hidden,present=useOverlayPresence(isOpen&&!!message);
  if(message)lastMessage.current=message;
  const setOpen=(value:boolean)=>{if(!value&&persistenceId)try{window.localStorage.setItem(announcementStorageKey(persistenceId),'1')}catch{/* storage can be unavailable */}if(open===undefined)setInnerOpen(value);onOpenChange?.(value)};
  const setIndex=(value:number)=>{if(!messages.length)return;const next=(value+messages.length)%messages.length;if(index===undefined)setInnerIndex(next);onIndexChange?.(next)};
  useEffect(()=>{const cb=()=>setHidden(document.hidden);document.addEventListener('visibilitychange',cb);cb();return()=>document.removeEventListener('visibilitychange',cb)},[]);
  useEffect(()=>{if(open===undefined)setInnerOpen(defaultOpen&&!wasAnnouncementDismissed(persistenceId))},[persistenceId]);
  useEffect(()=>{if(!isOpen||!autoPlay||paused||messages.length<2||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;const timer=setTimeout(()=>setIndex(active+1),Math.max(1000,interval));return()=>clearTimeout(timer)},[isOpen,autoPlay,paused,messages.length,active,interval]);
  useEffect(()=>{if(!message?.countdown)return;const update=()=>setNow(Date.now());update();const timer=setInterval(update,1000);return()=>clearInterval(timer)},[message?.id,message?.countdown?.to]);
  const clock=message?.countdown?countdownText(message.countdown.to,now):null;
  useEffect(()=>{if(clock?.ended&&message&&!endCalled.current.has(message.id)){endCalled.current.add(message.id);onCountdownEnd?.(message)}},[clock?.ended,message?.id,onCountdownEnd]);
  if(!present||!lastMessage.current)return null;
  const shownMessage=message??lastMessage.current;
  return <div id={domId} className={`cap-announcement-bar ${className}`} role="region" aria-label={label} aria-hidden={!isOpen} inert={!isOpen} data-state={isOpen?'open':'closed'} onPointerEnter={e=>{if(e.pointerType==='mouse')setHovered(true)}} onPointerLeave={e=>{if(e.pointerType==='mouse')setHovered(false)}} onFocusCapture={()=>setFocused(true)} onBlurCapture={e=>{if(!e.currentTarget.contains(e.relatedTarget as Node|null))setFocused(false)}}><div className="cap-announcement-inner"><div className="cap-announcement-content"><span key={shownMessage.id} className="cap-announcement-message">{shownMessage.message}</span>{shownMessage.countdown&&clock&&<span className="cap-announcement-countdown" role="timer" aria-label={shownMessage.countdown.label??'Time remaining'}>{clock.ended?'Ended':clock.text}</span>}{shownMessage.action&&(shownMessage.action.href?<a href={shownMessage.action.href} className="cap-button cap-announcement-action" data-variant="ghost" data-size="sm" onClick={()=>{shownMessage.action?.onClick?.();onAction?.(shownMessage)}}>{shownMessage.action.label}</a>:<Button type="button" size="sm" variant="ghost" className="cap-announcement-action" onClick={()=>{shownMessage.action?.onClick?.();onAction?.(shownMessage)}}>{shownMessage.action.label}</Button>)}</div><div className="cap-announcement-controls">{controls&&messages.length>1&&<><Button type="button" variant="ghost" size="sm" aria-label="Previous announcement" onClick={()=>setIndex(active-1)}><Icon name="chevron" className="cap-announcement-prev-icon"/></Button><Button type="button" variant="ghost" size="sm" aria-label={manuallyPaused?'Resume announcements':'Pause announcements'} onClick={()=>setManuallyPaused(v=>!v)}>{manuallyPaused?'Play':'Pause'}</Button><Button type="button" variant="ghost" size="sm" aria-label="Next announcement" onClick={()=>setIndex(active+1)}><Icon name="chevron"/></Button></>}{dismissible&&<Button type="button" variant="ghost" size="sm" aria-label="Dismiss announcement" onClick={()=>setOpen(false)}><Icon name="close"/></Button>}</div></div></div>
}

export type CardDecision = 'previous' | 'next' | 'left' | 'right';
export type CardReviewDecision = 'left' | 'right';
export interface CardStackProps<T> {
  items: T[];
  activeIndex?: number;
  defaultIndex?: number;
  onActiveIndexChange?: (index: number) => void;
  renderCard: (item: T, index: number) => ReactNode;
  getKey?: (item: T, index: number) => string;
  getLabel?: (item: T, index: number) => string;
  /** A review deck consumes every card, including the last. Omit for simple previous/next browsing. */
  review?: boolean;
  labels?: { left: string; right: string };
  onDecision?: (item: T, decision: CardDecision) => void;
  onDecide?: (item: T, decision: CardReviewDecision) => void;
  onUndo?: (item: T, decision: CardDecision) => void;
  onReset?: () => void;
  renderEmpty?: ReactNode | ((reset: () => void) => ReactNode);
  label?: string;
  className?: string;
}
type CardHistory<T> = { index: number; item: T; decision: CardDecision };
export function CardStack<T>({items,activeIndex,defaultIndex=0,onActiveIndexChange,renderCard,getKey,getLabel=(_,i)=>`Card ${i+1}`,review=false,labels={left:'Pass',right:'Keep'},onDecision,onDecide,onUndo,onReset,renderEmpty,label='Card review',className=''}:CardStackProps<T>){
  const [inner,setInner]=useState(defaultIndex),[history,setHistory]=useState<Array<CardHistory<T>>>([]),[dragX,setDragX]=useState(0),[returnDirection,setReturnDirection]=useState(-1),[returning,setReturning]=useState(false),[exit,setExit]=useState<{item:T;index:number;direction:number}|null>(null),[message,setMessage]=useState('');
  const drag=useRef<{pointerId:number;startX:number;width:number}|null>(null),exitTimer=useRef<ReturnType<typeof setTimeout>|null>(null),returnTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const current=Math.max(0,Math.min(review?items.length:Math.max(0,items.length-1),activeIndex??inner)),deck=items.slice(current,current+3),complete=review&&current>=items.length;
  useEffect(()=>()=>{if(exitTimer.current)clearTimeout(exitTimer.current);if(returnTimer.current)clearTimeout(returnTimer.current)},[]);
  const setIndex=(index:number)=>{if(activeIndex===undefined)setInner(index);onActiveIndexChange?.(index)};
  const clearExit=()=>{if(exitTimer.current)clearTimeout(exitTimer.current);exitTimer.current=setTimeout(()=>setExit(null),210)};
  const decide=(decision:CardReviewDecision)=>{
    if(!review||complete||!items[current])return;
    const item=items[current],direction=decision==='left'?-1:1;
    setExit({item,index:current,direction});clearExit();setHistory(previous=>[...previous,{index:current,item,decision}]);setIndex(current+1);setDragX(0);
    setMessage(`${getLabel(item,current)}: ${labels[decision]}. ${items.length-current-1} remaining.`);
    onDecision?.(item,decision);onDecide?.(item,decision);
  };
  const move=(next:number,decision:'previous'|'next')=>{
    if(review||!items.length)return;
    const index=Math.max(0,Math.min(items.length-1,next));if(index===current)return;
    const item=items[current],direction=decision==='next'?-1:1;
    setExit({item,index:current,direction});clearExit();setHistory(previous=>[...previous,{index:current,item,decision}]);setIndex(index);setDragX(0);
    setMessage(`${getLabel(item,current)}: ${decision}.`);onDecision?.(item,decision);
  };
  const undo=()=>{
    const last=history.at(-1);if(!last)return;
    if(exitTimer.current)clearTimeout(exitTimer.current);setExit(null);setReturnDirection(last.decision==='next'||last.decision==='left'?-1:1);setReturning(true);
    if(returnTimer.current)clearTimeout(returnTimer.current);returnTimer.current=setTimeout(()=>setReturning(false),210);
    setHistory(previous=>previous.slice(0,-1));setIndex(last.index);setMessage(`${getLabel(last.item,last.index)} restored.`);onUndo?.(last.item,last.decision);
  };
  const reset=()=>{if(!review)return;if(exitTimer.current)clearTimeout(exitTimer.current);setExit(null);setHistory([]);setIndex(0);setDragX(0);setMessage('All cards restored.');onReset?.()};
  const interactiveTarget=(target:EventTarget|null)=>target instanceof Element&&!!target.closest('button,a,input,textarea,select,[contenteditable="true"],[role="button"],[role="link"]');
  const down=(e:ReactPointerEvent<HTMLDivElement>)=>{if(e.button!==0||interactiveTarget(e.target)||!deck.length)return;drag.current={pointerId:e.pointerId,startX:e.clientX,width:e.currentTarget.getBoundingClientRect().width||320};e.currentTarget.setPointerCapture?.(e.pointerId)};
  const movePointer=(e:ReactPointerEvent<HTMLDivElement>)=>{if(drag.current?.pointerId===e.pointerId)setDragX(e.clientX-drag.current.startX)};
  const up=(e:ReactPointerEvent<HTMLDivElement>)=>{const state=drag.current;if(!state||state.pointerId!==e.pointerId)return;const delta=e.clientX-state.startX;drag.current=null;if(Math.abs(delta)>Math.min(64,state.width*.22)){if(review)decide(delta<0?'left':'right');else move(current+(delta<0?1:-1),delta<0?'next':'previous')}else setDragX(0)};
  const cancel=(e:ReactPointerEvent<HTMLDivElement>)=>{if(drag.current?.pointerId!==e.pointerId)return;drag.current=null;setDragX(0)};
  const onKeyDown=(e:React.KeyboardEvent<HTMLDivElement>)=>{if(e.target!==e.currentTarget)return;if(e.key==='ArrowRight'){e.preventDefault();review?decide('right'):move(current+1,'next')}else if(e.key==='ArrowLeft'){e.preventDefault();review?decide('left'):move(current-1,'previous')}else if((e.key==='Backspace'||((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='z'))&&history.length){e.preventDefault();undo()}};
  const empty=typeof renderEmpty==='function'?renderEmpty(reset):renderEmpty;
  if(!items.length)return <section className={`cap-card-stack ${className}`} role="region" aria-label={label}>{empty??<p>No cards</p>}</section>;
  return <section className={`cap-card-stack ${className}`} role="region" aria-label={label} data-review={review||undefined}>
    <div className="cap-card-stack-stage" role="group" aria-roledescription="card stack" aria-label={label} tabIndex={0} onKeyDown={onKeyDown} onPointerDown={down} onPointerMove={movePointer} onPointerUp={up} onPointerCancel={cancel}>
      {deck.slice().reverse().map((item,reverseIndex)=>{const depth=deck.length-1-reverseIndex,index=current+depth,active=depth===0,offset=active?dragX:0,lift=drag.current?Math.min(1,Math.abs(dragX)/120):0;return <div key={getKey?.(item,index)??index} className={`cap-card-stack-card${active&&returning?' cap-card-stack-returning':''}`} data-depth={depth} data-dragging={active&&drag.current!==null||undefined} data-surface="raised" aria-label={`${getLabel(item,index)}, ${index+1} of ${items.length}`} aria-hidden={!active||undefined} inert={!active} style={{'--cap-card-depth':depth,'--cap-card-x':`${offset}px`,'--cap-card-y':`${depth*10-lift*depth*8}px`,'--cap-card-scale':1-depth*.045+lift*depth*.025,'--cap-card-rotation':`${offset*.035}deg`,'--cap-card-return-x':`${returnDirection*26}px`} as CSSProperties}>{renderCard(item,index)}{review&&active&&Math.abs(offset)>24&&<span className="cap-card-stack-stamp" data-direction={offset<0?'left':'right'} aria-hidden="true">{labels[offset<0?'left':'right']}</span>}</div>})}
      {exit&&<div key={`exit-${getKey?.(exit.item,exit.index)??exit.index}`} className="cap-card-stack-card cap-card-stack-exit" data-surface="raised" aria-hidden="true" inert style={{'--cap-card-x':`${exit.direction*110}%`,'--cap-card-rotation':`${exit.direction*8}deg`} as CSSProperties}>{renderCard(exit.item,exit.index)}</div>}
      {complete&&!exit&&<div className="cap-card-stack-empty">{empty??<><p>All cards reviewed</p><Button type="button" variant="ghost" size="sm" onClick={reset}>Start over</Button></>}</div>}
    </div>
    <div className="cap-card-stack-controls">
      {review?<><Button type="button" variant="outline" size="sm" onClick={()=>decide('left')} disabled={complete}>{labels.left}</Button><Button type="button" variant="ghost" size="sm" onClick={undo} disabled={!history.length}><Icon name="arrow"/>Undo</Button><Button type="button" variant="accent" size="sm" onClick={()=>decide('right')} disabled={complete}>{labels.right}</Button></>:<><Button type="button" variant="outline" size="sm" onClick={()=>move(current-1,'previous')} disabled={current===0}><Icon name="chevron" className="cap-announcement-prev-icon"/>Previous</Button><span aria-live="polite">{current+1} of {items.length}</span><Button type="button" variant="outline" size="sm" onClick={()=>move(current+1,'next')} disabled={current===items.length-1}>Next<Icon name="chevron"/></Button><Button type="button" variant="ghost" size="sm" onClick={undo} disabled={!history.length}><Icon name="arrow"/>Undo</Button></>}
    </div>
    <span role="status" aria-live="polite" className="cap-sr-only">{message}</span>
  </section>;
}

export interface TextShimmerProps { children:string; active?:boolean; duration?:number; as?:'span'|'p'|'div'|'h2'|'h3'|'h4'; className?:string; id?:string }
export function TextShimmer({children,active=true,duration=1.8,as='span',className='',id}:TextShimmerProps){const ref=useRef<HTMLElement|null>(null);const [visible,setVisible]=useState(true);useEffect(()=>{const node=ref.current;if(!node||typeof IntersectionObserver==='undefined')return;const observer=new IntersectionObserver(entries=>setVisible(entries[0]?.isIntersecting??false),{rootMargin:'64px'});observer.observe(node);return()=>observer.disconnect()},[]);const Tag=as;return <Tag ref={ref as never} id={id} className={`cap-text-shimmer ${className}`} data-active={active&&visible||undefined} aria-busy={active} style={{'--cap-shimmer-duration':`${Math.max(.4,duration)}s`} as CSSProperties}>{children}</Tag>}
