import { useId, useRef, useState, type CSSProperties, type HTMLAttributes, type ReactNode } from 'react';
import { IconButton, cx } from './primitives.js';
export interface ContentPane {
  content: ReactNode; label: string; open?: boolean; onOpenChange?: (open: boolean) => void;
  width?: number; defaultWidth?: number; minWidth?: number; maxWidth?: number; onWidthChange?: (width: number) => void;
  contentWidth?: number | string; surface?: 'base' | 'canvas' | 'raised' | 'floating';
}
export interface ContentLayoutProps extends HTMLAttributes<HTMLDivElement> { left?: ContentPane; right?: ContentPane; contentWidth?: number | string; label?: string }
export function ContentLayout({left,right,contentWidth='100%',label='Контент',children,className,...props}: ContentLayoutProps) {
  const root=useRef<HTMLDivElement>(null), id=useId();
  const [widths,setWidths]=useState({left:left?.defaultWidth??240,right:right?.defaultWidth??280});
  const drag=useRef<{side:'left'|'right';start:number;width:number}|null>(null);
  const getWidth=(side:'left'|'right')=>{const pane=side==='left'?left:right;return Math.min(pane?.maxWidth??600,Math.max(pane?.minWidth??160,pane?.width??widths[side]));};
  const resize=(side:'left'|'right',requested:number)=>{
    const pane=side==='left'?left:right, other=side==='left'?right:left;
    const available=(root.current?.clientWidth||1600)-240-(other&&other.open!==false?getWidth(side==='left'?'right':'left')+8:0)-8;
    const width=Math.round(Math.max(pane?.minWidth??160,Math.min(pane?.maxWidth??600,available,requested)));
    if(pane?.width===undefined)setWidths(current=>({...current,[side]:width}));
    pane?.onWidthChange?.(width);
  };
  const renderPane=(side:'left'|'right')=>{
    const pane=side==='left'?left:right;
    if(!pane||pane.open===false)return null;
    const width=getWidth(side), resizable=pane.width===undefined||!!pane.onWidthChange;
    const handle=resizable?<div role="separator" tabIndex={0} aria-orientation="vertical" aria-label={`Ширина: ${pane.label}`} aria-controls={`${id}-${side}`} aria-valuemin={pane.minWidth??160} aria-valuemax={pane.maxWidth??600} aria-valuenow={width} className="cap-content-resizer" onPointerDown={event=>{if(event.button!==0)return;event.currentTarget.setPointerCapture(event.pointerId);drag.current={side,start:event.clientX,width};}} onPointerMove={event=>{const active=drag.current;if(active?.side===side)resize(side,active.width+(event.clientX-active.start)*(side==='left'?1:-1));}} onPointerUp={event=>{drag.current=null;if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);}} onPointerCancel={()=>{drag.current=null;}} onLostPointerCapture={()=>{drag.current=null;}} onKeyDown={event=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();resize(side,event.key==='Home'?pane.minWidth??160:event.key==='End'?pane.maxWidth??600:width+(event.key==='ArrowRight'?1:-1)*(side==='left'?1:-1)*(event.shiftKey?40:10));}}/>:null;
    const panel=<section id={`${id}-${side}`} role="region" aria-label={pane.label} className="cap-content-pane" data-surface={pane.surface??'raised'} style={{'--cap-pane-width':`${width}px`} as CSSProperties}><header><strong>{pane.label}</strong>{pane.onOpenChange&&<IconButton icon="close" size="sm" variant="ghost" label={`Закрыть: ${pane.label}`} onClick={()=>pane.onOpenChange?.(false)}/>}</header><div className="cap-content-pane-scroll"><div className="cap-content-pane-inner" style={{maxWidth:pane.contentWidth}}>{pane.content}</div></div></section>;
    return <>{side==='right'&&handle}{panel}{side==='left'&&handle}</>;
  };
  return <div ref={root} className={cx('cap-content-layout',className)} {...props}><div className="cap-content-layout-row">{renderPane('left')}<section role="region" aria-label={label} className="cap-content-main" data-surface="base"><div style={{maxWidth:contentWidth}}>{children}</div></section>{renderPane('right')}</div></div>;
}
