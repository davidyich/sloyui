import { useLayoutEffect, useState, type RefObject, type CSSProperties } from 'react';
/** One measured local layer. No animation loop or per-frame layout reads. */
export function MovingHighlight({ root, selected, hover = false, revision }: { root: RefObject<HTMLElement | null>; selected?: string; hover?: boolean; revision?: unknown }) {
  const [box,setBox]=useState<CSSProperties>({opacity:0});
  // The parent ref can be attached after this child's layout effect on the first commit.
  useLayoutEffect(()=>{
    let parent:HTMLElement|null=null,observer:ResizeObserver|null=null,frame:number|undefined,alive=true;
    let target:HTMLElement|null=null;
    const measure=()=>{if(!parent)return;const node=target??(selected?parent.querySelector<HTMLElement>(selected):null);if(!node){setBox(b=>({...b,opacity:0}));return;}const a=parent.getBoundingClientRect(),b=node.getBoundingClientRect();setBox({width:b.width,height:b.height,transform:`translate(${b.left-a.left+parent.scrollLeft-parent.clientLeft}px,${b.top-a.top+parent.scrollTop-parent.clientTop}px)`,opacity:1});};
    const enter=(e:Event)=>{const node=(e.target as Element)?.closest<HTMLElement>('button:not(:disabled),label:has(input:not(:disabled))');target=node&&parent?.contains(node)?node:null;measure();};
    const leave=()=>{target=null;measure();};
    const connect=()=>{if(!alive)return;const node=root.current;if(!node)return;if(parent!==node){parent=node;observer=typeof ResizeObserver!=='undefined'?new ResizeObserver(measure):null;observer?.observe(parent);if(hover){parent.addEventListener('pointerover',enter);parent.addEventListener('focusin',enter);parent.addEventListener('pointerleave',leave);parent.addEventListener('focusout',leave);}}const selectedNode=selected?node.querySelector<HTMLElement>(selected):null;if(selectedNode)observer?.observe(selectedNode);measure();};
    connect();queueMicrotask(connect);if(typeof requestAnimationFrame!=='undefined')frame=requestAnimationFrame(connect);
    return()=>{alive=false;if(frame!==undefined)cancelAnimationFrame(frame);observer?.disconnect();parent?.removeEventListener('pointerover',enter);parent?.removeEventListener('focusin',enter);parent?.removeEventListener('pointerleave',leave);parent?.removeEventListener('focusout',leave);};
  },[root,selected,hover,revision]);
  return <span aria-hidden="true" className="cap-moving-highlight" data-visible={box.opacity===1||undefined} style={box}/>;
}
