import { mkdtemp, mkdir, symlink, readFile, writeFile, copyFile, rm, access } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve, join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { build } from 'esbuild';
import { gzipSync } from 'node:zlib';
const version = JSON.parse(await readFile('package.json', 'utf8')).version;
const root = process.cwd(), tarball = resolve(process.argv[2] ?? `artifacts/personal-capacities-ui-${version}.tgz`);
await access(tarball);
const temp = await mkdtemp(join(tmpdir(), 'capacities-consumer-'));
try {
  const target = join(temp, 'node_modules/@personal/capacities-ui');
  await mkdir(target, { recursive: true });
  execFileSync('tar', ['-xzf', tarball, '--strip-components=1', '-C', target]);
  for (const name of ['react', 'react-dom', '@types']) await symlink(join(root, 'node_modules', name), join(temp, 'node_modules', name));
  await writeFile(join(temp, 'package.json'), '{"type":"module"}');
  const examples = ['ProjectBoard', 'WorkspaceV2', 'IntegratedWorkspace', 'CalendarSchedule'];
  for (const example of examples) await copyFile(join(target, `examples/${example}.tsx`), join(temp, `${example}.tsx`));
  await writeFile(join(temp, 'consumer.tsx'), `import { Button, Dialog, Field, Input, type Color, type Size } from '@personal/capacities-ui';\nimport { IntegratedWorkspace } from './IntegratedWorkspace.js';\nimport '@personal/capacities-ui/styles.css';\nconst color: Color = 'teal'; const size: Size = 'xl';\nexport const demo = <Dialog size="xl" open={false} onOpenChange={() => {}} title="Test"><Field label="Title">{p => <Input {...p} size={size} />}</Field><Button variant="outline" size={size}>{color}</Button></Dialog>;\nexport const integrated = <IntegratedWorkspace/>;\n`);
  await writeFile(join(temp, 'tsconfig.json'), JSON.stringify({ compilerOptions: { target: 'ES2022', module: 'NodeNext', moduleResolution: 'NodeNext', jsx: 'react-jsx', strict: true, noEmit: true, skipLibCheck: false, lib: ['ES2022', 'DOM', 'DOM.Iterable'] }, include: ['*.tsx'] }));
  execFileSync(join(root, 'node_modules/.bin/tsc'), ['-p', join(temp, 'tsconfig.json')], { stdio: 'pipe' });
  await writeFile(join(temp, 'render.mjs'), `import React from 'react';import {renderToString} from 'react-dom/server';import {Button,BarChart,ComboBox,ColorPicker,DataTable,HoverPanel,LineChart,MultiSelect,NavigationMenu,NumberField,RadioGroup,RichTextEditor,TagInput,ToastStack,TreeView,ValueScrubber} from '@personal/capacities-ui';const node=React.createElement,rows=[{id:'a',name:'Task',value:2}],columns=[{id:'name',header:'Name',value:r=>r.name},{id:'value',header:'Value',value:r=>r.value}],document={blocks:[{id:'p',type:'paragraph',content:[{text:'Note'}]}]};const html=renderToString(node(React.Fragment,null,node(Button,{variant:'primary'},'Hello'),node(ComboBox,{label:'Project',options:[{value:'a',label:'Alpha'}]}),node(MultiSelect,{label:'Topics',options:[{value:'a',label:'Alpha'}]}),node(TagInput,{label:'Tags'}),node(RadioGroup,{label:'Layout',options:[{value:'grid',label:'Grid'}]}),node(ColorPicker,{label:'Color'}),node(NumberField,{label:'Zoom'}),node(ValueScrubber,{label:'Scrubber',value:5,onValueChange:()=>{}}),node(NavigationMenu,{label:'Navigation',items:[{id:'a',label:'A',content:node('a',{href:'#a'},'Link')}]}),node(HoverPanel,{label:'Preview',summary:'Preview',children:'Body'}),node(TreeView,{label:'Tree',nodes:[{id:'a',label:'Alpha'}]}),node(LineChart,{label:'Line',series:[{name:'A',values:[1,2]}]}),node(BarChart,{label:'Bars',data:[{label:'A',value:1}]}),node(RichTextEditor,{label:'Note',value:document,onValueChange:()=>{}}),node(DataTable,{label:'Tasks',rows,columns,rowId:r=>r.id}),node(ToastStack,{items:[],onDismiss:()=>{}})));for(const token of ['cap-button','cap-selection-field','cap-value-scrubber','cap-navigation-menu','cap-tree','cap-chart','cap-rich-editor','cap-data-table','cap-toast-stack'])if(!html.includes(token))throw Error('SSR smoke missing '+token);console.log('SSR smoke passed for new public component exports');`);
  execFileSync(process.execPath, [join(temp, 'render.mjs')], { stdio: 'pipe' });
  const fontCss = await readFile(join(target, 'dist/fonts.css'), 'utf8');
  const fontPaths = [...fontCss.matchAll(/url\(([^)]+)\)/g)].map(m => m[1]);
  for (const path of fontPaths) await access(join(target, 'dist', path));
  const manifest = JSON.parse(await readFile(join(target, 'agent-manifest.json'), 'utf8'));
  const packed = await build({ stdin: { contents: "export { Button } from '@personal/capacities-ui';", resolveDir: temp }, bundle: true, write: false, minify: true, format: 'esm', external: ['react','react-dom','react/jsx-runtime'] });
  const report = { package: manifest.package, componentCount: manifest.componentCount, isolatedArchiveConsumer: true, nodeNextTypes: true, exampleTypecheck: examples, serverRenderImport: true, serverRenderedExports: ['ComboBox', 'MultiSelect', 'TagInput', 'RadioGroup', 'ColorPicker', 'NumberField', 'ValueScrubber', 'NavigationMenu', 'HoverPanel', 'TreeView', 'LineChart', 'BarChart', 'RichTextEditor', 'DataTable', 'ToastStack'], fontAssets: fontPaths.length, buttonGzipBytes: gzipSync(packed.outputFiles[0].contents).length };
  await writeFile(join(root, 'docs/package-validation.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(report);
} catch (error) {
  if (error.stdout) console.error(error.stdout.toString());
  if (error.stderr) console.error(error.stderr.toString());
  throw error;
} finally { await rm(temp, { recursive: true, force: true }); }
