import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import Documents from '../demo/Documents';
const original={path:'docs/overview.md',content:'# Original',revision:'v1'};
const response=(data:unknown,ok=true)=>Promise.resolve({ok,json:async()=>data});
beforeEach(()=>sessionStorage.clear());
afterEach(()=>vi.unstubAllGlobals());
describe('instruction editor',()=>{
 it('saves the edited text with its revision and returns to the real-file preview',async()=>{
  const fetch=vi.fn().mockImplementationOnce(()=>response(original)).mockImplementationOnce(()=>response({...original,content:'# Updated',revision:'v2'}));vi.stubGlobal('fetch',fetch);
  render(<Documents/>);await screen.findByRole('heading',{name:'Original'});fireEvent.click(screen.getByRole('button',{name:'Редактировать'}));fireEvent.change(screen.getByRole('textbox',{name:'Редактор docs/overview.md'}),{target:{value:'# Updated'}});fireEvent.click(screen.getByRole('button',{name:'Сохранить'}));await screen.findByRole('heading',{name:'Updated'});expect(JSON.parse(fetch.mock.calls[1][1].body)).toEqual({content:'# Updated',revision:'v1'});expect(sessionStorage.getItem('cap-document-draft:docs/overview.md')).toBeNull();
 });
 it('retains a conflicting draft and requires reviewing the new disk version before retrying',async()=>{
  const fetch=vi.fn().mockImplementationOnce(()=>response(original)).mockImplementationOnce(()=>response({error:'Файл изменён другим редактором'},false)).mockImplementationOnce(()=>response({...original,content:'# External',revision:'v2'})).mockImplementationOnce(()=>response({...original,content:'# My change',revision:'v3'}));vi.stubGlobal('fetch',fetch);
  render(<Documents/>);await screen.findByRole('heading',{name:'Original'});fireEvent.click(screen.getByRole('button',{name:'Редактировать'}));fireEvent.change(screen.getByRole('textbox',{name:'Редактор docs/overview.md'}),{target:{value:'# My change'}});fireEvent.click(screen.getByRole('button',{name:'Сохранить'}));await screen.findByText('Файл изменён другим редактором');expect(screen.getByRole('textbox',{name:'Редактор docs/overview.md'})).toHaveValue('# My change');expect(sessionStorage.getItem('cap-document-draft:docs/overview.md')).toBe('# My change');fireEvent.click(screen.getByRole('button',{name:'Показать версию на диске'}));await screen.findByRole('heading',{name:'External'});fireEvent.click(screen.getByRole('button',{name:'Продолжить с моим текстом'}));fireEvent.click(screen.getByRole('button',{name:'Сохранить'}));await waitFor(()=>expect(fetch).toHaveBeenCalledTimes(4));expect(JSON.parse(fetch.mock.calls[3][1].body)).toEqual({content:'# My change',revision:'v2'});await screen.findByRole('heading',{name:'My change'});
 });
});
